"""Capture a review command, redact inherited secrets, and record its exit code."""

import json
import os
from pathlib import Path
import subprocess
import sys
import time

log_path = Path(sys.argv[1]).resolve()
command = sys.argv[2:]
start = time.monotonic()
result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
output = result.stdout.decode("utf-8", errors="replace")
for key, value in os.environ.items():
    if (
        value
        and len(value) >= 4
        and any(
            token in key.upper()
            for token in ("PASSWORD", "SECRET", "TOKEN", "ACCESS_KEY")
        )
    ):
        output = output.replace(value, "<redacted>")
output = output.replace(str(Path.cwd()), "<review-checkout>")
log_path.parent.mkdir(parents=True, exist_ok=True)
log_path.write_text(output, encoding="utf-8")
record = {
    "command": command,
    "exit_code": result.returncode,
    "elapsed_seconds": round(time.monotonic() - start, 3),
}
log_path.with_suffix(".result.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record))
sys.exit(result.returncode)
