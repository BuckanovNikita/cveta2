# Dataset and conversion review evidence

- Review date: 2026-10-03
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`
- Scope owner: dataset models, partitioning, fetch/output/merge/whats-new services, and conversion services
- Method: line-by-line static review, contract/test comparison, targeted unit suite, and isolated local reproductions; no live integration and no product-code changes

## Governing evidence

Read before review:

- `AGENTS.md`
- `.specify/memory/constitution.md`
- `.specify/memory/engineering.md`
- `.specify/memory/architecture.md`
- `specs/001-project-documentation/contracts/dataset-format.md`
- `specs/001-project-documentation/evidence/bug-review-2026-09-04.md`

The historical dispositions were preserved. BR-02 (tracks unsupported with warnings), BR-03 (globally unique basename/stem input contract), and BR-05 (duplicate-basename lookup contract) were not reopened. The former BR-06 YOLO `path` defect is fixed in the reviewed code and covered by current tests.

## Files reviewed

| Module | Review result |
|---|---|
| `cveta2/models.py` | Reviewed all model fields, validators, CSV serialization, discriminated records, and merge helpers. No reportable defect found under the documented basename/path contract. |
| `cveta2/dataset_partition.py` | Reviewed completion fallback, deleted-row precedence, `task_id` recency, stale/latest splitting, empty frames, and deletion deduplication. No reportable defect found. |
| `cveta2/services/fetch.py` | Reviewed cache policy, task fan-out, skip behavior, per-task artifacts, pruning, image download, path population, and result merge. No reportable defect found in this bounded service layer. |
| `cveta2/services/output.py` | Reviewed CSV read/write options, schema checks, path enrichment, empty outputs, and summaries. DATA-005 found at the shared parser boundary. |
| `cveta2/services/merge.py` | Reviewed generated and legacy deletion inputs, split propagation, conflict selection, numeric task recency, and output I/O. DATA-001 found. |
| `cveta2/services/whats_new.py` | Reviewed cutoff fallback, completed-task aggregation, sibling CSV handling, and known/unfinished task sets. No reportable defect found. |
| `cveta2/services/convert/__init__.py` | Reviewed public conversion exports. No independent defect found. |
| `cveta2/services/convert/common.py` | Reviewed coordinate conversions, link/copy modes, source resolution, size caching, split validation, export preparation, and CSV row construction. DATA-002 and DATA-003 found. |
| `cveta2/services/convert/yolo.py` | Reviewed export labels/tree pruning/YAML, label parsing, class maps, dataset-root/list resolution, label resolution, dataset mode, prediction mode, and empty/missing inputs. DATA-002, DATA-003, DATA-006, and DATA-007 found. |
| `cveta2/services/convert/coco.py` | Reviewed image/category/annotation identities, bbox conversion, split naming, JSON writing, repeat output behavior, and shared image placement. DATA-003 and DATA-004 found. |

Relevant tests and documentation reviewed included `tests/test_models.py`, `tests/test_partition.py`, `tests/test_output.py`, `tests/test_fetch_service.py`, `tests/test_fetch_task.py`, `tests/test_merge.py`, `tests/test_whats_new.py`, `tests/test_convert_common.py`, `tests/test_convert_yolo.py`, `tests/test_convert_coco.py`, `README.md`, `docs/cli.md`, `docs/python-api.md`, and `docs/images-and-cache.md`.

## Findings

| ID | Severity | Status | Observation |
|---|---|---|---|
| [DATA-001](../findings/DATA-001/report.md) | Medium | Reproduced | Generated `deleted.csv` parsing treats literal `NA` filenames as null, so merge keeps a deleted image. |
| [DATA-002](../findings/DATA-002/report.md) | Medium | Reproduced | Unsupported split names pass validation; YOLO writes files that `dataset.yaml` does not reference. |
| [DATA-003](../findings/DATA-003/report.md) | Medium | Reproduced | Repeat export keeps existing image bytes even when the selected source changed. |
| [DATA-004](../findings/DATA-004/report.md) | Unrated pending contract decision | Unclear contract; stale-output observation reproduced | A repeat COCO export retains splits, JSON, and images removed from the current input; replacement versus incremental behavior needs a product decision. |
| [DATA-005](../findings/DATA-005/report.md) | Low | Reproduced | Malformed CSV raises raw pandas `ParserError` across the service/CLI boundary. |
| [DATA-006](../findings/DATA-006/report.md) | Low | Reproduced | Malformed YOLO YAML raises raw PyYAML `ParserError` across the conversion/CLI boundary. |
| [DATA-007](../findings/DATA-007/report.md) | Medium | Reproduced | Fractional class ids are truncated and non-finite coordinates become malformed box rows without warnings. |

## Checks performed

Targeted unit regression suite:

```bash
uv run --locked pytest -q tests/test_models.py tests/test_partition.py tests/test_output.py tests/test_fetch_service.py tests/test_fetch_task.py tests/test_merge.py tests/test_whats_new.py tests/test_convert_common.py tests/test_convert_yolo.py tests/test_convert_coco.py
```

Result: `403 passed in 2.34s` on Python 3.12.13 with 12 xdist workers.

Each finding was independently reproduced with its exact command recorded in `findings/DATA-*/observed-output.txt`. All seven scripts exited 0 while asserting the current defective observation. They set `HOME`, `XDG_CACHE_HOME`, and `XDG_CONFIG_HOME` to per-run temporary directories and make no network calls.

## Hypotheses not promoted to findings

- `populate_record_paths()` does not clear a pre-existing `image_path` when the current local file is absent. Current fetch results and cache writes initialize/cache records before local path population, so no supported production path to stale data was established.
- The `.tasks/` directory can remain after an exception and its normal cleanup is best-effort. This is documented as a debugging artifact, and no distinct loss of final fetch output was reproduced.
- Conversion filters record shapes to `box` and `none`; deleted rows are intentionally outside exported detection datasets. No contract requiring an error for filtered deletion rows was found.

No full suite or live integration run was performed; those were explicitly outside this bounded review.
