# Interface/configuration review evidence

Review date: 2026-10-03  
Baseline commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`  
Reviewer scope: CLI entry points, public workflow API, commands and interactive
adapters, configuration/presets, exception types, projects cache, and their
public documentation/tests. No product code was changed.

## Result

Six findings were reproduced:

| ID | Severity | Status | Summary |
|---|---|---|---|
| UI-001 | Medium | Reproduced | Project name `..` escapes `cache.images_root` |
| UI-002 | Low | Reproduced | Pydantic config errors escape the CLI as tracebacks |
| UI-003 | Medium | Reproduced | Negative data timeouts reach HTTP setup and raise `ValueError` |
| UI-004 | Low | Reproduced | `setup-clearml` can discard an explicit enabled-state change |
| UI-005 | Low | Reproduced | A remotely deleted task cannot be removed noninteractively from ignore config |
| UI-006 | Low | Reproduced | Custom-profile credential errors name the ambient config path |

Each finding folder contains an English report and an executable isolated
reproduction. The reports record the expected contract, actual observation,
exact command/output, code references, impact, and a future acceptance
assertion.

## Review method

The review read `AGENTS.md`, the constitution, engineering guidance,
architecture context, and the historical 2026-09-04 bug review before source
inspection. It then:

1. Inventoried every owned source file and the corresponding tests/docs.
2. Traced CLI parser arguments through command adapters and compared them with
   public API signatures, configuration lookup, organization/project selection,
   prompts, and error translation.
3. Searched all owned code for prompts, `sys.exit`, exception catches/raises,
   config reads/writes, and path derivation.
4. Checked explicit invalid and empty inputs, custom-config isolation,
   noninteractive behavior, stale local state, and setup/doctor flows.
5. Reduced material candidates to standalone scripts using temporary HOME,
   XDG cache, config, and fake/in-process boundaries only.
6. Rechecked prior dispositions rather than treating the historical review as
   an open work queue.

## Complete source inventory

| Files | Result |
|---|---|
| `cveta2/cli.py` | No separate finding; parser/dispatch/error boundary inspected. UI-002 demonstrates the boundary gap caused by non-domain config errors. |
| `cveta2/api.py` | UI-005, UI-006. Remote functions remained prompt-free in the inspected paths. Explicit personal-workspace override from BR-09 remains fixed. |
| `cveta2/__init__.py`, `cveta2/__main__.py` | No findings; exports and module entry point agree with the public API/CLI surfaces. |
| `cveta2/config.py` | UI-001, UI-002, UI-003, UI-006. All section loaders, serializers, precedence helpers, environment readers, cache-path derivation, and model constraints inspected. |
| `cveta2/exceptions.py` | No finding in the hierarchy itself; UI-002/UI-003 are failures to translate into it. |
| `cveta2/projects_cache.py` | No finding; invalid cache degradation, org filtering, update/write paths, and custom adjacent cache behavior inspected. |
| `cveta2/presets/__init__.py`, `cveta2/presets/default.yaml` | No finding; defaults agree with documented localhost/upload defaults. |
| `cveta2/commands/__init__.py` | No finding. |
| `cveta2/commands/_bootstrap.py`, `cveta2/commands/_helpers.py` | No independent finding; connection bootstrap, prompt ownership, project cache/org scoping, command echo quoting, and host errors inspected. |
| `cveta2/commands/convert.py` | No finding; direction-specific required input validation and argument forwarding inspected. |
| `cveta2/commands/doctor.py` | No independent finding beyond UI-002; config/AWS/cache checks and permission repair/error handling inspected. Doctor's warning-only exit status is not documented as an automation contract, so it was not promoted from ambiguity to a defect. |
| `cveta2/commands/fetch.py` | No finding; project/task inference, output overwrite behavior, selector resolution, image directory selection, cache flags, and echoed commands inspected. CLI precedence for simultaneous `--no-images` and `--images-dir` is explicitly tested; the public API deliberately rejects its analogous conflicting arguments. |
| `cveta2/commands/ignore.py` | UI-005; add/list/interactive paths otherwise had no material finding. |
| `cveta2/commands/labels.py` | No finding; add/rename/recolor/delete prompts, cancellation, destructive confirmations, and label refreshes inspected. |
| `cveta2/commands/merge.py` | No finding in the adapter. Dataset merge internals were outside this reviewer's ownership. |
| `cveta2/commands/s3_sync.py` | No finding; one/all-project target resolution, override validation, skipped-project reporting, and config fallback inspected. |
| `cveta2/commands/setup.py` | No finding; custom config/cache adjacency fixes from BR-07 remain present. Cache path generation reaches UI-001 through `config.py`. |
| `cveta2/commands/setup_clearml.py` | UI-004; custom adjacent project-cache handling from BR-07 remains fixed. |
| `cveta2/commands/task_ops.py` | No finding; required operands, state mapping, confirmations, task-session invalidation scaffold, and command echoes inspected. |
| `cveta2/commands/upload.py` | No finding; label sentinel/all handling, deleted-only behavior, prompt/echo parity (including BR-11 `--resume`), and option forwarding inspected. |
| `cveta2/commands/whats_new.py` | No finding; baseline read, project resolution, echo, and output paths inspected. |
| `cveta2/commands/interactive/__init__.py` | No finding; export seam matches command imports. |
| `cveta2/commands/interactive/_history.py` | No finding; history remains under the isolated per-user cache. |
| `cveta2/commands/interactive/_questionary.py` | No finding; this remains the only direct Questionary boundary. |
| `cveta2/commands/interactive/credentials.py` | No finding; prompting stays in CLI-only code and noninteractive guards precede input. |
| `cveta2/commands/interactive/entities.py` | No finding; org paging, rescan/cache, project/task/label selections, cancellation, and org switching inspected. |
| `cveta2/commands/interactive/primitives.py` | No finding; cancellation exits are nonzero, loop cancellations return `None`, and every prompt is guarded by `require_interactive`. |
| `cveta2/commands/interactive/wizard.py` | UI-004 through the enabled-state answer consumed by setup-clearml; other setup/cache prompt defaults and guards inspected. |

Dependency-only inspection of `cveta2/services/resolve.py`,
`cveta2/services/fetch.py`, `cveta2/services/upload.py`,
`cveta2/services/task_ops.py`, `cveta2/_client_ops/base.py`, and
`cveta2/_client_ops/fetch.py` was limited to proving interface behavior and
lineage. Their independent review belongs to the parent/other assigned scopes.

## Public tests and documentation inspected

The interface assertions and uncovered boundaries were checked against:

- `tests/test_api.py`, `tests/test_cli_parsing.py`, `tests/test_cli_images.py`,
  `tests/test_cli_s3_sync.py`, `tests/test_command_helpers.py`
- `tests/test_config_clearml.py`, `tests/test_config_helpers.py`,
  `tests/test_config_sections.py`, `tests/test_request_timeout.py`
- `tests/test_doctor.py`, `tests/test_doctor_checks.py`,
  `tests/test_fetch_task.py`, `tests/test_ignore_command.py`,
  `tests/test_interactive.py`, `tests/test_labels.py`
- `tests/test_merge.py`, `tests/test_projects_cache.py`,
  `tests/test_select_project.py`, `tests/test_setup.py`,
  `tests/test_task_ops.py`, `tests/test_upload_command.py`,
  `tests/test_upload_helpers.py`, `tests/test_upload_label_validation.py`,
  `tests/test_whats_new.py`, and `tests/test_docs.py`
- `README.md`, `docs/cli.md`, `docs/configuration.md`,
  `docs/images-and-cache.md`, and `docs/python-api.md`

Conversion service correctness and its dedicated conversion tests were left to
the assigned dataset reviewer; this review covered only the CLI/API exposure
and documented flag contract.

## Historical disposition recheck

- BR-07 remains fixed: setup-cache and setup-clearml derive `projects.yaml`
  beside the selected `--config` path.
- BR-08's malformed-YAML case remains fixed by `yaml.YAMLError` translation.
  UI-002 is the still-untranslated Pydantic half explicitly anticipated in the
  old finding, with a new executable reproduction.
- BR-09 remains fixed: `Connection(organization="")` explicitly selects the
  personal workspace after config merging.
- BR-11 remains fixed: prompted upload echoes `--resume`.
- BR-03 and BR-05 remain accepted input contracts and were not reopened.
- Other historical findings lie outside this bounded module ownership; no
  contrary disposition was asserted here.

## Executed checks

All six reproduction commands were run exactly as recorded in their reports.
Every script exited 0 after printing the reproduced condition; UI-002's inner
CLI subprocess exited 1 with both `Traceback` and `ValidationError`, as the
script records.

```text
uv run --locked ruff check bugs/review-2026-10-03/findings/UI-*/reproduce.py
Initial agent result only; superseded after parent assertion hardening.
```

No full or live suite was run in this bounded review; the parent owns those
checks. No CVAT, S3, ClearML, Kubernetes, or other live service was contacted.

## Limitations

- Reproductions use temporary local files and fake/injected clients. UI-001
  proves the resolved write target and performs the write only inside its
  temporary directory; it does not download a real object.
- UI-004 patches the wizard's established return-value seam to represent the
  user's answers, avoiding a real terminal session.
- UI-005 proves both public API behavior and the CLI's identical static path;
  it does not connect to a CVAT server to create and then delete a task.
- Organization/project service internals were inspected only where necessary
  to validate these interface observations, because their exhaustive ownership
  belongs to the parent reviewer.

## Final proof-script lint qualification

The final standalone proof scripts were checked separately after assertions were added. Ruff exits 1; see [log](check-logs/proof-ruff-ui.log). No current pass is claimed for these evidence scripts. The production baseline lint is recorded separately in checks.md; no production lint configuration was changed to exempt artifacts. UI-007 was added by the parent only as an unclear doctor automation contract, not a confirmed defect.
