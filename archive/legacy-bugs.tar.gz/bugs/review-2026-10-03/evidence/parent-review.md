# Parent review evidence

Review date: 2026-10-03. Commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`.

## Files and behavior inspected

| Area | Scope and result |
|---|---|
| `cveta2/image_downloader.py` | All path normalization/confinement, direct HEAD probes, basename fallback, cache checks, atomic downloads, sync listing and counters reviewed. STOR-004; STOR-003 retained only as unclear contract, outside confirmed bugs. Accepted BR-03/05 collisions were not reopened. |
| `cveta2/image_uploader.py` | Local path search, duplicate resolution, monthly/pinned key mapping, upload batching and boto3 failure boundary reviewed. STOR-001. |
| `cveta2/task_cache.py` | Envelope/version/revision checks, local/S3 read/write/deletion, backfill and prune reviewed. STOR-002. Cross-host namespace lacks host identity but matching IDs and revisions are required; no real cross-host stale hit was established, so this remains a limitation rather than a confirmed defect. |
| `cveta2/s3_utils.py`, `cveta2/s3_types.py` | Protocols, transfer errors/retries, client construction, timeout/pool policy, prefix boundaries, pagination and serial/parallel listings reviewed. STOR-001 at callers; STOR-003 is an unresolved unsupported-input contract question; no additional distinct defect proven. |
| `cveta2/fs_utils.py` | Shared permissions and atomic per-writer replacement reviewed. No independent defect established; cache-deletion behavior is STOR-002. |
| `cveta2/_concurrency.py`, `cveta2/_retry.py` | Context propagation, bounded workers, result order, failure/cancellation, budget/backoff and logging reviewed and tested in serial and concurrent opt-in cases. CVAT-005 concerns the caller's retry predicate. |
| `cveta2/_clearml/*` | Optional import/config guards, CSV publication, SDK error translation and warning boundary reviewed. Live tests cover publishing/finalization and cleanup. No independent defect established. |
| `cveta2/services/resolve.py` | ORG/PROJECT parsing, personal workspace, numeric/project cache lookup, task inference and root overrides reviewed. Parent extended CVAT-001 with duplicate project names in the delegated read layer. |
| `main.py`, `cveta2/services/__init__.py` | Entry-point/export scaffolding reviewed; no finding. |
| `scripts/clone_project_to_s3.py` | Frame collection/order, image reuse, label/attribute remapping, task creation, asynchronous wait and cloning reviewed. OPS-001. Attribute metadata and ordering preservation remain limited; not separately live-validated. |
| `scripts/upload_dataset_to_cvat.py` | YAML/class mapping, source collection, label parsing, image sizing and task/shape creation reviewed. OPS-002. The schema explicitly requires a names mapping; list-form YAML support was not promoted as a defect of this helper. |
| `scripts/export_cvat_fixtures.py` | Credentials, project selection, DTO/shape/track/frame serialization and file writing reviewed. No independent finding under its fixture-export contract. It is not a faithful full CVAT backup. |
| `scripts/mutation_test.sh`, `mutation_config.py`, `mutation_gate.py` | Scope fingerprinting, profile resolution, process exit/error handling, survivor parsing/filtering and stale equivalents reviewed. OPS-003; real full profile and invalid profile executed. |
| `scripts/check_commit_msg.py`, `check_version_drift.py` | Parsing/exemptions/validation and release-version check reviewed; version gate executed. No independent finding. No commit/push/release performed. |
| `scripts/integration_{env,up,test,stop,gate}.sh` | Tag ownership, credentials, bootstrap, seeding, extras, pytest isolation, cleanup and lifecycle failure paths reviewed. Up/test/reseed/test/stop executed in a disposable checkout with an explicitly minted tag. No pre-push gate or main-slot replacement executed. |
| Project manifests/hooks/docs | pyproject/lock/package contents, Python floor, quality hooks, gitignore, contribution guides, architecture/constitution and historical evidence inspected. Production checks passed; no CI Python matrix found. |
| Installed Spec Kit tooling | Project selection/persistence, template resolution, setup scripts, workflow metadata and skill links inspected for this repository's use; all tracked shell scripts passed syntax checks. No feature generation or framework modification performed. Exhaustive upstream-template/preset/extension testing is outside the executed checks. |

## Proof and constraints

The parent read every finding report, compared source evidence, reran every Python reproduction, and exercised the real mutation-profile failure. The independent proof reviewer assessed the highest-impact reports separately. Scripts assert or print the current defect; exit 0 means the reproduction observed it, not that production behavior is correct.

Task-owned live resources were removed. No tracked production file, existing test, configuration, workflow artifact, or historical review was changed. Existing untracked personal skill links were preserved. No commits or pushes were authorized or performed.
