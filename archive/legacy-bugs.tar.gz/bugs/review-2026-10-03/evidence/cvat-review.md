# CVAT client and upload review evidence

Review date: 2026-10-03

Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Scope and method

The review covered every Python module in `cveta2/_client/` and `cveta2/_client_ops/`, plus `cveta2/client.py`, `cveta2/services/upload.py`, `cveta2/services/task_ops.py`, and `cveta2/upload_manifest.py`. Relevant unit tests, fake CVAT port behavior, Russian user documentation, architecture guidance, and the dataset contract were compared with the implementation. No live CVAT, S3, ClearML, Kubernetes, or other shared resource was used.

Review emphasis was annotation conversion, job/frame mapping, task selectors, labels, error translation/retry behavior, upload sequencing, resume identity/reconciliation, issues, deleted frames, and partial remote state.

Historical dispositions were preserved:

- CVAT tracks remain intentionally unsupported and are warned about per task; this was not reopened.
- Unique image basenames and stems remain an accepted input contract; collision behavior was not reopened.

## Findings

| ID | Severity | Status | Summary |
|---|---|---|---|
| [CVAT-001](../findings/CVAT-001/report.md) | High | Reproduced | Duplicate task/project names resolve by list order, including destructive task operations. |
| [CVAT-002](../findings/CVAT-002/report.md) | Medium | Reproduced | Labeled rows with incomplete bbox coordinates are silently omitted. |
| [CVAT-003](../findings/CVAT-003/report.md) | High | Component reproduction + static end-to-end trace | Resume identity excludes annotation content and can preserve stale shapes. |
| [CVAT-004](../findings/CVAT-004/report.md) | Medium | Component reproduction + static call trace | Manifest unlink errors escape after remote completion and leave stale recovery state. |
| [CVAT-005](../findings/CVAT-005/report.md) | High | Reproduced with fake | A `503 Retry-After` replays non-idempotent CVAT writes. |

## Module coverage

No additional findings met the evidence threshold in these files:

- `cveta2/_client/__init__.py`
- `cveta2/_client/connection.py`
- `cveta2/_client/context.py`
- `cveta2/_client/dtos.py`
- `cveta2/_client/extractors.py`
- `cveta2/_client/mapping.py`
- `cveta2/_client/ports.py`
- `cveta2/_client/sdk_convert.py`
- `cveta2/_client/sdk_requests.py`
- `cveta2/_client_ops/__init__.py`
- `cveta2/_client_ops/base.py`
- `cveta2/_client_ops/images.py`
- `cveta2/_client_ops/read.py` (parent later confirmed duplicate project-name selection; see CVAT-001)
- `cveta2/_client_ops/session.py`
- `cveta2/_client_ops/shared.py`
- `cveta2/client.py`
- `cveta2/services/task_ops.py` beyond the shared selector defect in CVAT-001

Files with findings were also reviewed in full: `cveta2/_client/assembly.py`, `cveta2/_client/sdk_adapter.py`, `cveta2/_client_ops/fetch.py`, `cveta2/_client_ops/task_ops.py`, `cveta2/_client_ops/write.py`, `cveta2/services/upload.py`, and `cveta2/upload_manifest.py`.

The Ground Truth/replica issue-job selection path was examined but not promoted to a finding: upload-created tasks ordinarily contain only non-overlapping annotation jobs, and no live CVAT evidence was collected for issue creation after later job topology changes. Annotation property round-tripping (`occluded`, `z_order`, `rotation`, `source`, and attributes) was also not promoted because current user documentation promises bbox transfer but does not state that upload preserves all exported metadata.

## Reproduction checks

Each finding script creates an isolated temporary `HOME`, config root, cache root, and `CVETA2_CONFIG` path before importing project code.

Commands:

```bash
uv run --locked python bugs/review-2026-10-03/findings/CVAT-001/reproduce.py
uv run --locked python bugs/review-2026-10-03/findings/CVAT-002/reproduce.py
uv run --locked python bugs/review-2026-10-03/findings/CVAT-003/reproduce.py
uv run --locked python bugs/review-2026-10-03/findings/CVAT-004/reproduce.py
uv run --locked python bugs/review-2026-10-03/findings/CVAT-005/reproduce.py
```

Focused regression command:

```bash
uv run --locked pytest -q tests/test_client.py tests/test_client_ops_base.py tests/test_client_ops_fetch.py tests/test_client_ops_ports.py tests/test_fetch_audit_regressions.py tests/test_issues.py tests/test_sdk_adapter_conversion.py tests/test_sdk_requests.py tests/test_task_ops.py tests/test_upload_helpers.py tests/test_upload_label_validation.py tests/test_upload_manifest.py tests/test_upload_service.py
```

The full suite was intentionally not run; repository-wide verification is owned by the parent review.

Observed results:

- All five reproduction scripts exited 0 and printed the outcomes preserved in their finding reports.
- Focused client/upload regression set: `338 passed in 2.21s`.
- Documentation/link checks: `55 passed in 1.97s`.
- Initial agent lint passed before parent assertion hardening. That result is superseded: final proof-script Ruff exits 1 (see `check-logs/proof-ruff-cvat.log`). Standalone proof scripts are executable evidence, outside the passing production baseline lint claim.

## Limitations

- No live integration test or shared infrastructure action was performed.
- CVAT-005 uses the real retry predicate/wrapper with a fake ambiguous remote effect; whether a particular deployment emits a post-application 503 depends on its CVAT/proxy failure mode.
- Files owned by the parallel storage/concurrency, dataset, and CLI/API/config review tracks were consulted only where necessary to establish contracts or call-site impact and were not independently audited here.
