# Project review — 2026-10-03

Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`.

**26 findings: 22 confirmed defects, 3 unclear contracts, and 1 conditional retry risk.** Confirmed defects comprise 2 High, 12 Medium and 8 Low findings. The conditional risk is High if its deployment failure mode occurs; unclear contracts are unrated pending a decision.

This review covers bugs, errors and unclear behavior across all 76 application Python modules, maintained helpers, configuration, public contracts and quality/lifecycle checks. Application code, existing tests, configuration and historical evidence were left unchanged. Everything added by this task is under `bugs/`. Reports are in English as requested.

Start with CVAT-001 and CVAT-003: duplicate names can select a wrong mutation target, and resume can silently keep annotations that differ from the edited CSV. Review CVAT-005 separately because its ambiguous post-write response was simulated rather than observed on live services.

Each folder contains a report with expected/actual behavior, source locations, impact, a reproduction command and a future acceptance assertion or contract decision. It also contains a standalone reproducer and captured output. **A reproducer exiting 0 means it observed the reported behavior, not that the application passed a regression test.** Most proofs isolate filesystem/SDK/component boundaries; the report states whether the complete path was run or statically traced. OPS-003 was exercised through the actual mutation wrapper in a disposable checkout.

## Confirmed defects

| ID | Severity | Finding | Proof boundary | Evidence |
|---|---|---|---|---|
| [CVAT-001](findings/CVAT-001/report.md) | High | Duplicate task and project names resolve to arbitrary targets | Real resolver; deterministic cached objects | [script](findings/CVAT-001/reproduce.py), [output](findings/CVAT-001/observed-output.txt) |
| [CVAT-003](findings/CVAT-003/report.md) | High | Resume identity ignores annotation content | Real fingerprint and resume component; full path static | [script](findings/CVAT-003/reproduce.py), [output](findings/CVAT-003/observed-output.txt) |
| [CVAT-002](findings/CVAT-002/report.md) | Medium | Incomplete labeled boxes are silently omitted during upload | Real annotation builder/upload boundary; fake port | [script](findings/CVAT-002/reproduce.py), [output](findings/CVAT-002/observed-output.txt) |
| [CVAT-004](findings/CVAT-004/report.md) | Medium | Manifest cleanup failure escapes after remote upload succeeds | Real unlink permission failure; post-upload path static | [script](findings/CVAT-004/reproduce.py), [output](findings/CVAT-004/observed-output.txt) |
| [DATA-001](findings/DATA-001/report.md) | Medium | merge ignores deletions whose image name is a pandas NA token | Real conversion/reader; temporary input/output | [script](findings/DATA-001/reproduce.py), [output](findings/DATA-001/observed-output.txt) |
| [DATA-002](findings/DATA-002/report.md) | Medium | export accepts unsupported split values and writes an unreferenced YOLO tree | Real conversion/reader; temporary input/output | [script](findings/DATA-002/reproduce.py), [output](findings/DATA-002/observed-output.txt) |
| [DATA-003](findings/DATA-003/report.md) | Medium | repeat export silently keeps stale image bytes | Real conversion/reader; temporary input/output | [script](findings/DATA-003/reproduce.py), [output](findings/DATA-003/observed-output.txt) |
| [DATA-007](findings/DATA-007/report.md) | Medium | YOLO import accepts non-integral classes and non-finite coordinates | Real conversion/reader; temporary input/output | [script](findings/DATA-007/reproduce.py), [output](findings/DATA-007/observed-output.txt) |
| [OPS-001](findings/OPS-001-clone-reuses-first-task-images/report.md) | Medium | Cloning substitutes the first task's images into every task | Actual helper main; fake remote services | [script](findings/OPS-001-clone-reuses-first-task-images/reproduce.py), [output](findings/OPS-001-clone-reuses-first-task-images/observed-output.txt) |
| [OPS-002](findings/OPS-002-yolo-class-index-misassignment/report.md) | Medium | The dataset upload helper silently misassigns or drops class IDs | Actual helper main; real input files, fake remote services | [script](findings/OPS-002-yolo-class-index-misassignment/reproduce.py), [output](findings/OPS-002-yolo-class-index-misassignment/observed-output.txt) |
| [STOR-001](findings/STOR-001-upload-failure-escapes/report.md) | Medium | S3 upload errors escape the transfer failure accounting | Installed boto3 upload; botocore Stubber | [script](findings/STOR-001-upload-failure-escapes/reproduce.py), [output](findings/STOR-001-upload-failure-escapes/observed-output.txt) |
| [STOR-002](findings/STOR-002-read-only-corrupt-cache/report.md) | Medium | An invalid read-only cache aborts fetch | Real non-root filesystem permissions | [script](findings/STOR-002-read-only-corrupt-cache/reproduce.py), [output](findings/STOR-002-read-only-corrupt-cache/observed-output.txt) |
| [UI-001](findings/UI-001-cache-root-dotdot-escape/report.md) | Medium | A project named `..` escapes `cache.images_root` | Real cache path helper; temporary file write | [script](findings/UI-001-cache-root-dotdot-escape/reproduce.py), [output](findings/UI-001-cache-root-dotdot-escape/observed-output.txt) |
| [UI-003](findings/UI-003-negative-timeout-traceback/report.md) | Medium | Negative data timeouts are accepted and fail inside HTTP setup | Real config and HTTP/S3 client setup; no request | [script](findings/UI-003-negative-timeout-traceback/reproduce.py), [output](findings/UI-003-negative-timeout-traceback/observed-output.txt) |
| [DATA-005](findings/DATA-005/report.md) | Low | malformed dataset CSV escapes the service error boundary | Real conversion/reader; temporary input/output | [script](findings/DATA-005/reproduce.py), [output](findings/DATA-005/observed-output.txt) |
| [DATA-006](findings/DATA-006/report.md) | Low | malformed YOLO YAML escapes the conversion error boundary | Real conversion/reader; temporary input/output | [script](findings/DATA-006/reproduce.py), [output](findings/DATA-006/observed-output.txt) |
| [OPS-003](findings/OPS-003-invalid-mutation-profile/report.md) | Low | An invalid mutation profile prints an error but exits successfully | Actual mutation wrapper/gate; disposable checkout | [script](findings/OPS-003-invalid-mutation-profile/reproduce.sh), [output](findings/OPS-003-invalid-mutation-profile/observed-output.txt) |
| [STOR-004](findings/STOR-004-directory-counted-as-image/report.md) | Low | Image download treats a directory as a cached image | Real directory; downloader boundary | [script](findings/STOR-004-directory-counted-as-image/reproduce.py), [output](findings/STOR-004-directory-counted-as-image/observed-output.txt) |
| [UI-002](findings/UI-002-config-validation-traceback/report.md) | Low | Typed configuration errors bypass the CLI error boundary | Actual CLI subprocess; temporary typed config | [script](findings/UI-002-config-validation-traceback/reproduce.py), [output](findings/UI-002-config-validation-traceback/observed-output.txt) |
| [UI-004](findings/UI-004-setup-clearml-toggle-not-saved/report.md) | Low | `setup-clearml` can discard the chosen enabled state | Actual setup command; fake prompts/project listing | [script](findings/UI-004-setup-clearml-toggle-not-saved/reproduce.py), [output](findings/UI-004-setup-clearml-toggle-not-saved/observed-output.txt) |
| [UI-005](findings/UI-005-stale-ignore-entry-not-removable/report.md) | Low | Noninteractive removal cannot delete a stale ignore entry | Public API; fake empty task listing | [script](findings/UI-005-stale-ignore-entry-not-removable/reproduce.py), [output](findings/UI-005-stale-ignore-entry-not-removable/observed-output.txt) |
| [UI-006](findings/UI-006-custom-config-credential-hint/report.md) | Low | Missing-credential errors name the ambient config instead of `Connection.config_path` | Public API config/credential boundary | [script](findings/UI-006-custom-config-credential-hint/reproduce.py), [output](findings/UI-006-custom-config-credential-hint/observed-output.txt) |

## Conditional risk

| ID | Severity | Finding | Proof boundary | Evidence |
|---|---|---|---|---|
| [CVAT-005](findings/CVAT-005/report.md) | High | `503 Retry-After` replays non-idempotent CVAT writes | Real retry predicate/decorator; simulated ambiguous write | [script](findings/CVAT-005/reproduce.py), [output](findings/CVAT-005/observed-output.txt) |

## Unclear contracts

| ID | Severity | Finding | Proof boundary | Evidence |
|---|---|---|---|---|
| [DATA-004](findings/DATA-004/report.md) | Unrated | repeat COCO export retains removed splits and images | Real conversion/reader; temporary input/output | [script](findings/DATA-004/reproduce.py), [output](findings/DATA-004/observed-output.txt) |
| [STOR-003](findings/STOR-003-sync-key-collision/report.md) | Unrated | S3 sync collapses distinct leading-separator keys into one file | Real sync implementation; fake raw-key listing | [script](findings/STOR-003-sync-key-collision/reproduce.py), [output](findings/STOR-003-sync-key-collision/observed-output.txt) |
| [UI-007](findings/UI-007-doctor-exit-contract/report.md) | Unrated | Doctor's exit status does not express the health-check result | Actual CLI subprocess; temporary missing configuration | [script](findings/UI-007-doctor-exit-contract/reproduce.py), [output](findings/UI-007-doctor-exit-contract/observed-output.txt) |

## Verification and review coverage

The unchanged baseline passed 1777 tests on both Python 3.11 and 3.12. Branch-aware coverage on 3.12 was 92.07%. Serial opt-in cache/concurrency checks passed 284 tests. Live integration passed 35 tests; the separate suite with live fixture parameterizations passed 1923 tests. The configured full mutation scope completed with 6377 killed and 110 allowlisted equivalents out of 6487 mutants, with no unexplained survivors. Baseline static, architecture, packaging, documentation and version checks also passed. These results do not invalidate the new reproductions.

All 25 Python reproducers were rerun by the parent; OPS-003 has a separate real shell-wrapper run. Final CVAT/UI evidence-script Ruff checks fail on standalone assertion/style rules, and the logs are retained. Baseline lint passes predate these review artifacts; no final whole-tree lint/type or commit-readiness pass is claimed for them.

Live resources created for this review were removed, with exact-tag listings proving cleanup. Python 3.10/3.13 and other platforms remain unverified. Broader review coverage does not guarantee there are no additional defects.

- [Commands, exits, logs and live cleanup](checks.md)
- [All-module inventory and review ownership](coverage.md)
- [Historical finding crosswalk](historical-crosswalk.md)
- [Limitations and evidence confidence](limitations.md)
- [Machine-readable finding index](findings.json)
- [Reproduction commands and exits](evidence/reproduction-results.json)
- [Independent proof review and final artifact validation](evidence/final-review.md)

No fixes, commits, pushes or deployment changes are included. Future fixes need their own selected behavior contract and regression checks.
