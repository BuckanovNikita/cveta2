# Checks and observed results

All results are dated 2026-10-03 and apply to commit `875dca9b5cfc5bb48218257624defe3c18bc4f6e`. Existing tracked files were clean at the start. Baseline static checks ran before review-only scripts were added, so their pass does not claim that standalone proof scripts follow every application lint/type rule.

| Command / check | Exit | Observed result | Proof |
|---|---:|---|---|
| `uv run --locked pytest --cov=cveta2 --cov-report=term-missing --cov-report=json:<temporary-output>` | 0 | Python 3.12.13: 1777 passed, 80 warnings; branch-aware coverage 92.07% | [log](evidence/check-logs/pytest-3.12.log), [coverage data](evidence/coverage.json) |
| `uv run --locked --python 3.11 pytest -n 4` | 0 | Python 3.11.15 disposable checkout: 1777 passed | [log](evidence/check-logs/pytest-3.11.log) |
| `uv run --locked pytest -n 0 tests/test_concurrency.py tests/test_retry_policy.py tests/test_task_cache.py tests/test_image_downloader.py tests/test_s3_utils.py tests/test_request_timeout.py` | 0 | 284 passed; opt-in cache/worker/error cases included | [log](evidence/check-logs/cache-concurrency-serial.log) |
| `uv run --locked ruff check .` | 0 | Baseline clean | [log](evidence/check-logs/ruff.log) |
| `uv run --locked ruff format --check .` | 0 | Baseline formatting clean; no rewriting | [log](evidence/check-logs/ruff-format.log) |
| `uv run --locked mypy .` | 0 | Baseline strict typing passed | [log](evidence/check-logs/mypy.log) |
| `uv run --locked lint-imports` | 0 | Architecture contracts passed | [log](evidence/check-logs/imports.log) |
| `uv run --locked vulture` | 0 | Baseline dead-code check passed | [log](evidence/check-logs/vulture.log) |
| `uv lock --check` | 0 | Lock consistency passed without updating lockfile | [log](evidence/check-logs/lock.log) |
| `uv build --no-sources --out-dir <temporary-output>` | 0 | Wheel and sdist built | [log](evidence/check-logs/build.log) |
| `uv run --locked python scripts/check_version_drift.py` | 0 | 0.6.0 matches v0.6.0 | [log](evidence/check-logs/version-drift.log) |
| `uv run --locked pytest tests/test_docs.py` | 0 | 55 passed | [log](evidence/check-logs/docs.log) |
| `bash -n <each tracked shell script>` | 0 | 12 scripts passed | [results](evidence/check-logs/shell-syntax.json) |
| `bash scripts/mutation_test.sh --profile full --max-children 8` | 0 | Fresh disposable checkout: 6487 total, 6377 killed, 110 justified equivalents; no unexplained survivors | [log](evidence/check-logs/mutation-full.log), [exit record](evidence/check-logs/mutation-full.result.json), [stats](evidence/mutation-stats.json) |
| `bash scripts/mutation_test.sh --profile review-does-not-exist --max-children 8` | 0 | Defective observation: unknown profile error ignored, full cached scope succeeds | [OPS-003](findings/OPS-003-invalid-mutation-profile/report.md) |
| Every `findings/*/reproduce.py` | 0 | Parent independently reran 25 Python scripts; assertions/output establish reported observations | [commands/exits](evidence/reproduction-results.json), individual `observed-output.txt` files |

Additional delegated targeted results (reported by agents, not separately rerun as the identical selectors by the parent): dataset/model/conversion 403 passed; client/upload 338 passed; agent docs 55 passed. Their scope is contained in the parent's full suites. See [dataset](evidence/dataset-review.md), [CVAT](evidence/cvat-review.md), and [interface](evidence/interface-review.md) evidence.

## Live integration and cleanup

Used the repository integration skills and lifecycle scripts in a disposable checkout. Infrastructure preflight returned GO. The minted owned tag was `cveta2-codex-20261003-full-review-bys4`; no durable main slot or existing run was adopted.

1. `bash scripts/integration_up.sh`: exit 0, seeded owned CVAT/MinIO data.
2. `bash scripts/integration_test.sh tests/integration`: exit 0, **35 passed**, 160 dependency warnings. [Log](evidence/check-logs/integration-tests.log).
3. `bash scripts/integration_up.sh`: exit 0, reseeded the same owned tag for fresh fixture tests.
4. `bash scripts/integration_test.sh tests --ignore=tests/integration`: exit 0, **1923 passed**, 80 warnings. This includes normal JSON parameterizations and additional live-CVAT parameterizations; it does not mean 1923 distinct network integration tests. [Log](evidence/check-logs/live-fixture-suite.log).
5. `bash scripts/integration_stop.sh`: exit 0. [Cleanup log](evidence/check-logs/integration-stop.log).
6. Exact-tag helper listings and the project identity's cloud-storage listing: zero CVAT projects/tasks/cloud storages, zero MinIO buckets, zero ClearML projects/tasks for this run. [Cleanup proof](evidence/check-logs/cleanup-proof.log).

Raw secret values were redacted before logs were written. The project access-key value equals a common project token, so redaction also replaces that token in some filenames/tag displays; the full tag above identifies the reviewed run. No credentials or reusable local setup instructions are persisted.

Python 3.10 and 3.13 were not installed and were not downloaded during the review. Those compatibility versions remain **unverified**. No application code, existing tests, or lockfile was changed to make any check pass.

## Evidence-script checks

Final CVAT/UI proof-script Ruff checks exit 1, with standalone assertion/style findings preserved in [CVAT log](evidence/check-logs/proof-ruff-cvat.log) and [UI log](evidence/check-logs/proof-ruff-ui.log). Agent creation-time lint passes are superseded by parent assertion hardening. These artifacts have not passed the full application lint/type gate, and no commit-readiness claim is made for the review bundle. Production checks above refer to the unchanged baseline, not newly added proof scripts.

## Final artifact handoff

The independent read-only proof reviewer returned SHIP after evidence corrections. [Review receipt](evidence/final-review.md), [artifact/link/ownership validation](evidence/check-logs/artifact-validation.json) and [local temporary-resource cleanup](evidence/check-logs/local-cleanup.json) are retained. Tracked and staged diffs are empty; only `bugs/` was added alongside the two preserved pre-existing untracked skill links.
