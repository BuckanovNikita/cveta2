# Historical findings crosswalk

The [2026-09-04 review](../../specs/001-project-documentation/evidence/bug-review-2026-09-04.md) is unchanged. Its dispositions are historical evidence, not a reopened work queue.

| Historical ID | Current disposition and evidence |
|---|---|
| BR-01 | Former frame traversal paths are rejected by key validation and resolved destination confinement; image-downloader/S3 tests passed. UI-001 is a different root-derivation boundary (project name); STOR-003 is an unresolved raw-key-fidelity contract question outside confirmed bug totals. |
| BR-02 | Tracks remain unsupported by design, with per-task warnings. Do not count this as a new extraction defect. |
| BR-03 | Unique basenames and stems across the project/dataset remain the accepted supported-input contract. Nested duplicate image identity was not reopened. |
| BR-04 | Cache schema 4, live `task_updated_date` equality, completion eligibility and incomplete-issue safeguards are present; cache tests and live behavior passed. STOR-002 concerns deletion permissions, not the old revision-invalidation bug. |
| BR-05 | Duplicate-basename lookup is an accepted input-contract disposition. No finding reopens first/last choice for unsupported distinct images sharing a basename. STOR-003 retains that exact-key collision observation only as a contract question outside the guaranteed input domain. |
| BR-06 | YOLO `path` root resolution is present and the conversion tests passed. DATA-006 concerns syntax error translation, not root resolution. |
| BR-07 | Setup commands derive projects-cache paths beside the selected custom config; setup/config tests passed. |
| BR-08 | Malformed configuration YAML is now translated. UI-002 reproduces untranslated typed validation at the same boundary; DATA-005/006 concern separate CSV/YOLO readers. The old report anticipated Pydantic handling, but its primary YAML-syntax observation remains fixed. |
| BR-09 | Explicit `Connection(organization="")` retains personal-workspace selection; API/org-resolution tests passed. |
| BR-10 | Deleted-frame updates compute newly changed IDs and avoid no-op PATCHes; task-operation tests passed, including live operations. |
| BR-11 | Prompted upload command echoes include `--resume`; upload-command tests passed. |

See the subsystem inventories for detailed code/test comparison. No claim here converts a passing regression suite into proof that every related boundary is correct.
