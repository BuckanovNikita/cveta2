# DATA-001: merge ignores deletions whose image name is a pandas NA token

- Severity: Medium
- Status: Reproduced
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`
- Historical relationship: new finding; it is separate from accepted BR-03/BR-05 basename behavior.

## Expected behavior and contract

The dataset contract says textual columns preserve literal values such as `"NA"`. A name present in the supplied `deleted.csv` must be removed from the merged result.

## Observed behavior and cause

`read_dataset_csv()` preserves `"NA"`, so the old dataset contains that literal name. `_read_deleted_names()` instead calls bare `pd.read_csv()`, which applies pandas' default NA tokens, converts `"NA"` to null, and then drops it. The merge retains the supposedly deleted image.

Source evidence: `cveta2/services/merge.py:40-52` (line numbers at the reviewed commit).

## Impact

An image named `NA` (and other pandas NA spellings) can silently survive a merge even when the new fetch explicitly deleted it. The merged training dataset can therefore retain content users intended to remove.

## Reproduction

Run from the repository root:

```bash
uv run --locked python bugs/review-2026-10-03/findings/DATA-001/reproduce.py
```

The script uses an isolated temporary home and asserts the current defective result. See [observed output](observed-output.txt).

## Future acceptance assertion

Merge a dataset containing literal `image_name=NA` with a generated-format `deleted.csv` containing the same name; assert the merged frame is empty and the text value is never coerced to null.
