"""Reproduce loss of literal image names while reading deleted.csv."""

import os
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory(prefix="cveta2-data-001-") as temporary:
    root = Path(temporary)
    os.environ["HOME"] = str(root / "home")
    os.environ["XDG_CACHE_HOME"] = str(root / "cache")
    os.environ["XDG_CONFIG_HOME"] = str(root / "config")

    from loguru import logger

    from cveta2.services.merge import merge_datasets

    logger.remove()

    header = (
        "image_name,instance_shape,instance_label,bbox_x_tl,bbox_y_tl,"
        "bbox_x_br,bbox_y_br,split\n"
    )
    row = "NA,box,cat,0,0,1,1,train\n"
    old_path = root / "old.csv"
    new_path = root / "new.csv"
    deleted_path = root / "deleted.csv"
    output_path = root / "merged.csv"
    old_path.write_text(header + row, encoding="utf-8")
    new_path.write_text(header, encoding="utf-8")
    deleted_path.write_text("image_name,instance_shape\nNA,deleted\n", encoding="utf-8")

    merged = merge_datasets(
        old_path,
        new_path,
        output_path,
        deleted=deleted_path,
    )
    print("deleted.csv requested:", ["NA"])
    print("merged image_name values:", merged["image_name"].tolist())
    print("literal deletion applied:", merged.empty)
    assert merged["image_name"].tolist() == ["NA"]
