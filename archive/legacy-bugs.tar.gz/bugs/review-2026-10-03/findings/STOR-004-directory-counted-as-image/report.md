# STOR-004-directory-counted-as-image: Image download treats a directory as a cached image

- Severity: Low
- Status: Reproduced using an existing directory
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`
- Historical relationship: new finding; no production changes made.

## Expected behavior and contract

DownloadStats.cached is the number of already-downloaded files. A directory is not a completed image download; _download_all already uses is_file for its second cache check.

## Observed behavior and cause

ImageDownloader._filter_cached uses exists rather than is_file. A directory named a.jpg is counted as a cached image; no S3 read happens and the command reports success although no image file exists. S3Syncer uses the same existence-only check.

Source evidence: `cveta2/image_downloader.py:268-287,477-482` (line numbers at the reviewed commit).

## Impact

An accidental directory or conflicting cache layout hides a missing image. Downstream conversion or upload then fails after the fetch reported the image as cached.

## Reproduction

Run from the repository root, using the locked development environment:

```bash
uv run --locked python bugs/review-2026-10-03/findings/STOR-004-directory-counted-as-image/reproduce.py
```

The script asserts the current defective observation and exits 0 when reproduced. It uses temporary files or an in-memory S3 boundary; it makes no network calls. See [observed output](observed-output.txt).

## Future acceptance assertion

Place a directory at an expected image destination; assert it is rejected or counted as failed with a visible diagnostic and never counted as a valid cached file.
