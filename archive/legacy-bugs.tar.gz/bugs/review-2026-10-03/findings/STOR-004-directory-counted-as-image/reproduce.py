from pathlib import Path
from tempfile import TemporaryDirectory
from cveta2.image_downloader import CloudStorageInfo, ImageDownloader
from cveta2.models import ImageWithoutAnnotations, ProjectAnnotations

with TemporaryDirectory() as tmp:
    destination = Path(tmp)
    (destination / "a.jpg").mkdir()
    record = ImageWithoutAnnotations(
        image_name="a.jpg",
        image_width=1,
        image_height=1,
        task_id=1,
        task_name="t",
        frame_id=0,
    )
    stats = ImageDownloader(destination).download(
        ProjectAnnotations(annotations=[record], deleted_images=[]),
        CloudStorageInfo(id=1, bucket="test-bucket", prefix="root", endpoint_url=""),
    )
    print("Reported:", stats.model_dump())
    print("Image is a regular file:", (destination / "a.jpg").is_file())
    assert (
        stats.cached == 1
        and stats.failed == 0
        and not (destination / "a.jpg").is_file()
    )
