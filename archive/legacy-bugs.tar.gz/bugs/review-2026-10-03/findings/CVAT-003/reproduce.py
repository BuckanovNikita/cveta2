"""Reproduce resume accepting changed bbox content as the same upload."""

# Reproduction scripts intentionally print evidence and delay project imports
# until after HOME/config/cache isolation is installed.
# ruff: noqa: INP001, PLC0415, T201

import os
import tempfile
from unittest.mock import MagicMock


def main() -> None:
    """Run the isolated content-blind resume reproduction."""
    with tempfile.TemporaryDirectory() as isolated:
        os.environ["HOME"] = isolated
        os.environ["XDG_CONFIG_HOME"] = f"{isolated}/config"
        os.environ["XDG_CACHE_HOME"] = f"{isolated}/cache"
        os.environ["CVETA2_CONFIG"] = f"{isolated}/config/cveta2/config.yaml"

        import pandas as pd

        from cveta2.image_downloader import CloudStorageInfo
        from cveta2.services.upload import _ensure_annotations, _StagedUpload
        from cveta2.upload_manifest import compute_fingerprint

        original = pd.DataFrame(
            [
                {
                    "image_name": "a.jpg",
                    "instance_shape": "box",
                    "instance_label": "car",
                    "bbox_x_tl": 1.0,
                    "bbox_y_tl": 2.0,
                    "bbox_x_br": 3.0,
                    "bbox_y_br": 4.0,
                }
            ]
        )
        edited = pd.DataFrame(
            [
                {
                    "image_name": "a.jpg",
                    "instance_shape": "box",
                    "instance_label": "car",
                    "bbox_x_tl": 100.0,
                    "bbox_y_tl": 2.0,
                    "bbox_x_br": 130.0,
                    "bbox_y_br": 4.0,
                }
            ]
        )
        original_fingerprint = compute_fingerprint(
            original["image_name"].tolist(), [], ["car"]
        )
        edited_fingerprint = compute_fingerprint(
            edited["image_name"].tolist(), [], ["car"]
        )
        staged = _StagedUpload(
            cs_info=CloudStorageInfo(
                id=3,
                bucket="bucket",
                prefix="prefix",
                endpoint_url="http://s3.invalid",
            ),
            annotations=edited,
            task_image_names=["prefix/a.jpg"],
            name_to_server_file={"a.jpg": "a.jpg"},
        )
        client = MagicMock()
        client.count_task_shapes.return_value = 1
        reported = _ensure_annotations(client, 77, staged, object(), resuming=True)

        print(f"counted_task={client.count_task_shapes.call_args.args[0]}")
        print(f"original_bbox_x={original.iloc[0]['bbox_x_tl']}")
        print(f"edited_bbox_x={edited.iloc[0]['bbox_x_tl']}")
        print(f"fingerprints_equal={original_fingerprint == edited_fingerprint}")
        print(f"reported_shapes={reported}")
        print(f"upload_called={client.upload_task_annotations.called}")
        assert original_fingerprint == edited_fingerprint
        assert original.iloc[0]["bbox_x_tl"] != edited.iloc[0]["bbox_x_tl"]
        assert reported == 1 and not client.upload_task_annotations.called


if __name__ == "__main__":
    main()
