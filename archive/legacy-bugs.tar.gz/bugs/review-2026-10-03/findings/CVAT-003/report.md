# CVAT-003 — Resume identity ignores annotation content

- Severity: High
- Status: Component-reproduced; end-to-end resume flow statically validated
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Expected

`--resume` must continue the exact recorded annotation intent, or reject a CSV whose bbox/label/issue content changed after the interrupted run. It must not claim the edited input was uploaded while preserving different shapes already on the task.

## Actual

The manifest fingerprint includes only sorted image names, deleted names, and the requested label-selection arguments. It excludes bbox coordinates, actual per-row labels, annotation count, attributes, and issue content. On resume, any non-zero shape count causes the entire current annotation DataFrame to be skipped. Two inputs with the same frame set and requested labels but different boxes therefore share one manifest, and the edited boxes are silently ignored.

## Reproduction

```bash
uv run --locked python bugs/review-2026-10-03/findings/CVAT-003/reproduce.py
```

Observed output:

```text
counted_task=77
original_bbox_x=1.0
edited_bbox_x=100.0
fingerprints_equal=True
reported_shapes=1
upload_called=False
```

## Code evidence

- `cveta2/upload_manifest.py:63-77` hashes only frame/deletion/selection lists.
- `cveta2/services/upload.py:370-377` interprets any existing shape as proof that all shapes for the current input already landed.
- `cveta2/services/upload.py:563-568` uses that content-blind fingerprint to authorize resume.

The atomic bulk-write assumption prevents replay duplication, but it does not prove that the current CSV describes the bulk write already stored on CVAT.

## Impact

Editing boxes or labels after an interrupted run can yield a successful command whose CVAT task contains the old annotations. Editing both boxes and issues can create a mixed task: old shapes are retained while new issues are created at edited coordinates. The manifest is then deleted as if the edited input completed.

## Future acceptance assertion

Given an interrupted upload whose task contains bbox `[1, 2, 3, 4]`, a resume request with the same frame and selected class but bbox `[100, 2, 130, 4]` is rejected before remote writes (or is reconciled exactly); it never returns success while keeping the old bbox.

## Evidence boundary

The script invokes real `compute_fingerprint()` using each DataFrame's frame identities and the real `_ensure_annotations()` with an injected shape count. Assertions prove equal fingerprints despite different boxes and that the current edited annotations are skipped. It does not execute `upload_dataset()` end to end; linking the fingerprint to manifest selection and subsequent annotation skipping is static source evidence at the cited call sites.
