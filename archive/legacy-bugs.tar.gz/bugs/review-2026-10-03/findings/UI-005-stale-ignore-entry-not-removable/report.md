# UI-005 — Noninteractive removal cannot delete a stale ignore entry

- Severity: Low
- Status: Reproduced
- Commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Expected contract

Both `cveta2 ignore --remove TASK` and `cveta2.ignore(..., remove=[TASK])` are
documented as removing entries from the local per-project ignore list
(`docs/python-api.md:50-54`; `docs/cli.md:414-429`). A task ID
already stored locally must remain removable after the remote task is deleted;
stale entries are exactly the entries that need local cleanup.

## Actual observation

The public API lists current remote tasks and resolves both additions and
removals against that list before touching the local config
(`cveta2/api.py:561-573`). The CLI repeats the same resolution for `--remove`
(`cveta2/commands/ignore.py:90-104`, `126-133`). If task 42 no longer exists,
selector resolution raises `TaskNotFoundError`, and the stored ID remains.
The interactive removal path does not have this problem because it selects
directly from stored entries (`cveta2/commands/ignore.py:268-299`).

Command:

```text
uv run --locked python bugs/review-2026-10-03/findings/UI-005-stale-ignore-entry-not-removable/reproduce.py
```

Observed output:

```text
failure_type=TaskNotFoundError
failure=Task not found: '42'. Available tasks:
remaining=[42]
```

## Impact

Automation and noninteractive users cannot clean deleted or otherwise hidden
tasks from the ignore configuration. They must enable the TUI or hand-edit
YAML, and stale entries persist indefinitely in scripted environments.

## Future acceptance assertion

Given a stored ignored task whose ID is absent from the current CVAT project,
removing that numeric ID through both CLI and Python API succeeds and deletes
only that local entry. Name-based removal may still require an unambiguous
stored or remote name.

## Captured proof

The parent reran the reproduction independently. See [observed output](observed-output.txt) and the shared [reproduction results](../../evidence/reproduction-results.json). Exit 0 indicates the defective observation was reproduced, not that the intended behavior passed.
