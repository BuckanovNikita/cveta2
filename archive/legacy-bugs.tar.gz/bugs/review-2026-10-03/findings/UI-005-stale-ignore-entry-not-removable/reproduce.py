"""Reproduce failure to remove an ignored task deleted from CVAT."""

# ruff: noqa: ANN001, ANN201, ARG002, D101, D102, I001, INP001, T201

import os
import tempfile
from pathlib import Path
from unittest.mock import patch


with tempfile.TemporaryDirectory(prefix="cveta2-ui-005-") as raw_tmp:
    tmp = Path(raw_tmp)
    os.environ["HOME"] = str(tmp / "home")
    os.environ["XDG_CACHE_HOME"] = str(tmp / "xdg-cache")
    config = tmp / "profile" / "config.yaml"

    import cveta2
    from cveta2.client import CvatClient
    from cveta2.config import IgnoreConfig, IgnoredTask
    from cveta2.exceptions import TaskNotFoundError

    class FakeClient:
        is_ready = True

        def list_project_tasks(self, project_id):
            return []

        def resolve_task_selectors(self, tasks, selectors):
            return CvatClient.resolve_task_selectors(tasks, selectors)

    IgnoreConfig(
        projects={"project": [IgnoredTask(id=42, name="deleted remotely")]}
    ).save(config)
    connection = cveta2.Connection(client=FakeClient(), config_path=config)
    with patch("cveta2.api.resolve_project_spec", return_value=(1, "project")):
        try:
            cveta2.ignore(1, remove=[42], connection=connection)
        except TaskNotFoundError as exc:
            print(f"failure_type={type(exc).__name__}")
            print(f"failure={exc}")
        else:
            raise AssertionError(
                "Stale task removal no longer raises TaskNotFoundError"
            )
    remaining = IgnoreConfig.load(config).get_ignored_tasks("project")
    print(f"remaining={remaining}")
    assert remaining == [42]
