"""Reproduce a project name escaping the configured cache root."""

# ruff: noqa: I001, INP001, T201

import os
import tempfile
from pathlib import Path


with tempfile.TemporaryDirectory(prefix="cveta2-ui-001-") as raw_tmp:
    tmp = Path(raw_tmp)
    os.environ["HOME"] = str(tmp / "home")
    os.environ["XDG_CACHE_HOME"] = str(tmp / "xdg-cache")
    os.environ["CVETA2_CONFIG"] = str(tmp / "config.yaml")

    from cveta2.config import CacheConfig, cache_dir_for_project

    root = tmp / "images"
    root.mkdir()
    CacheConfig(images_root=root).save(tmp / "config.yaml")

    derived = cache_dir_for_project(root, "..")
    destination = derived / "downloaded.jpg"
    destination.write_bytes(b"probe")

    print(f"configured_root={root}")
    print(f"derived_path={derived}")
    print(f"resolved_derived={derived.resolve()}")
    print(f"escaped_root={not derived.resolve().is_relative_to(root.resolve())}")
    print(f"outside_file_exists={(root.parent / 'downloaded.jpg').is_file()}")
    assert not derived.resolve().is_relative_to(root.resolve())
    assert (root.parent / "downloaded.jpg").is_file()
