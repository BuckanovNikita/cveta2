# UI-001 — A project named `..` escapes `cache.images_root`

- Severity: Medium (filesystem/data-integrity boundary)
- Status: Reproduced
- Commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Expected contract

The documented fallback for projects absent from `image_cache` is
`<cache.images_root>/<project name>` (`docs/images-and-cache.md:25`). The helper
also claims to replace path-unsafe characters (`cveta2/config.py:434-437`). The
derived directory must remain a child of the configured cache root for every
CVAT project name.

## Actual observation

`cache_dir_for_project()` replaces separators and NUL but leaves the complete
path components `.` and `..` unchanged (`cveta2/config.py:434-437`). A CVAT
project named `..` therefore resolves to the parent of `cache.images_root`.
`images_cache_dir_from()` returns that path as the fetch/sync target without a
containment check (`cveta2/config.py:440-456`).

Command:

```text
uv run --locked python bugs/review-2026-10-03/findings/UI-001-cache-root-dotdot-escape/reproduce.py
```

Observed output (temporary-directory suffix varies):

```text
configured_root=/tmp/cveta2-ui-001-xu3fodlf/images
derived_path=/tmp/cveta2-ui-001-xu3fodlf/images/..
resolved_derived=/tmp/cveta2-ui-001-xu3fodlf
escaped_root=True
outside_file_exists=True
```

## Impact

Normal fetch, fetch-task, s3-sync, setup-cache, and upload path resolution can
read or write one directory above the operator-selected cache root when the
remote project has this valid name. This can collide with unrelated files in
the cache root's parent and breaks the stated root boundary.

## Future acceptance assertion

For project names `.` and `..`, and for names containing separators or NUL,
the derived per-project directory resolves strictly below `images_root`; a
fetch/sync write cannot create a file at or above the resolved root.

## Captured proof

The parent reran the reproduction independently. See [observed output](observed-output.txt) and the shared [reproduction results](../../evidence/reproduction-results.json). Exit 0 indicates the defective observation was reproduced, not that the intended behavior passed.
