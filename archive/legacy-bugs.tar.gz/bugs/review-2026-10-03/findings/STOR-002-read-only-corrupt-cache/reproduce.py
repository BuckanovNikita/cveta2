from pathlib import Path
from tempfile import TemporaryDirectory
import os
from cveta2.models import TaskInfo
from cveta2.task_cache import TaskAnnotationCache

if os.geteuid() == 0:
    raise SystemExit("Unavailable: run as a non-root POSIX user")
with TemporaryDirectory() as tmp:
    cache_dir = Path(tmp) / "cache"
    cache_dir.mkdir()
    (cache_dir / "task_1.json").write_text("invalid json")
    cache_dir.chmod(0o555)
    try:
        task = TaskInfo(
            id=1,
            name="t",
            status="completed",
            subset="",
            updated_date="2026-10-03T00:00:00Z",
        )
        try:
            TaskAnnotationCache(cache_dir).get(task)
        except PermissionError:
            print("Observed: PermissionError while removing an invalid cache entry")
        else:
            raise AssertionError("Bug no longer observed")
    finally:
        cache_dir.chmod(0o755)
