# STOR-002-read-only-corrupt-cache: An invalid read-only cache aborts fetch

- Severity: Medium
- Status: Reproduced using real filesystem permissions as a non-root user
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`
- Historical relationship: new finding; no production changes made.

## Expected behavior and contract

The task_cache module states that a cache problem must never fail the fetch. Reading an invalid or unwritable optional cache should permit a live fetch; saving failures are already best effort.

## Observed behavior and cause

TaskAnnotationCache.get reads malformed JSON and recognizes a cache miss, then calls invalidate_local. unlink raises PermissionError in a readable directory without write permission, and it is not caught. prune and invalidation use the same uncaught removal path.

Source evidence: `cveta2/task_cache.py:278-280,290-313,315-333; cveta2/services/fetch.py:237-242,295-305` (line numbers at the reviewed commit).

## Impact

A stale or corrupted group-shared cache entry can make fetching fail even though CVAT is available. The symptom persists until the entry can be removed or cache reads are disabled.

## Reproduction

Run from the repository root, using the locked development environment:

```bash
uv run --locked python bugs/review-2026-10-03/findings/STOR-002-read-only-corrupt-cache/reproduce.py
```

The script asserts the current defective observation and exits 0 when reproduced. It uses temporary files or an in-memory S3 boundary; it makes no network calls. See [observed output](observed-output.txt).

## Future acceptance assertion

With a readable invalid cache in a non-writable directory, assert a miss with a warning, then verify the fetch calls CVAT. Record unsupported permission semantics on non-POSIX platforms.
