# UI-003 — Negative data timeouts are accepted and fail inside HTTP setup

- Severity: Medium (invalid-input boundary)
- Status: Reproduced
- Commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Expected contract

`CVETA2_DATA_TIMEOUT` and `cvat.request_timeout` represent seconds; the
documented disabled values are unset and zero (`docs/configuration.md:70`,
`docs/configuration.md:93`).
Negative and non-finite values should be rejected or ignored at configuration
load with a field-specific message, before a client or transfer is created.

## Actual observation

`_parse_timeout_env()` accepts every value that `float()` accepts
(`cveta2/config.py:197-208`), and `CvatConfig.request_timeout` has no range or
finiteness constraint (`cveta2/config.py:211-218`). Bootstrap installs `-1.0`
unchanged (`cveta2/_client/connection.py:31-38`). The first S3 client then
raises an unrelated raw `ValueError` from urllib3 while applying the timeout
(`cveta2/s3_utils.py:185-188`).

Command:

```text
uv run --locked python bugs/review-2026-10-03/findings/UI-003-negative-timeout-traceback/reproduce.py
```

Observed output:

```text
parsed_timeout=-1.0
failure_type=ValueError
failure=Attempted to set read timeout to -1.0, but the timeout cannot be set to a value less than or equal to 0.
```

## Impact

A one-run environment typo is accepted as configuration and fails later at a
network implementation boundary. Depending on the command, users receive a
traceback far from the bad setting instead of the existing invalid-env warning
style. The same negative value can be loaded from YAML.

## Future acceptance assertion

Loading negative, NaN, or infinite timeouts from either YAML or
`CVETA2_DATA_TIMEOUT` never reaches `configure_data_timeout`; the user receives
a message naming the setting, while zero and positive finite values retain
their documented behavior.

## Captured proof

The parent reran the reproduction independently. See [observed output](observed-output.txt) and the shared [reproduction results](../../evidence/reproduction-results.json). Exit 0 indicates the defective observation was reproduced, not that the intended behavior passed.
