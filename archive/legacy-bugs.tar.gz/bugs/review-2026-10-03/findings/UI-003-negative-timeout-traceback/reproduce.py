"""Reproduce acceptance of a negative network data timeout."""

# ruff: noqa: I001, INP001, T201

import os
import tempfile
from pathlib import Path


with tempfile.TemporaryDirectory(prefix="cveta2-ui-003-") as raw_tmp:
    tmp = Path(raw_tmp)
    os.environ.update(
        {
            "HOME": str(tmp / "home"),
            "XDG_CACHE_HOME": str(tmp / "xdg-cache"),
            "CVETA2_CONFIG": str(tmp / "config.yaml"),
            "CVETA2_DATA_TIMEOUT": "-1",
            "AWS_ACCESS_KEY_ID": "test",
            "AWS_SECRET_ACCESS_KEY": "test",
            "AWS_DEFAULT_REGION": "us-east-1",
            "AWS_EC2_METADATA_DISABLED": "true",
        }
    )

    from cveta2._client.connection import configure_data_timeout
    from cveta2.config import CvatConfig
    from cveta2.s3_utils import make_s3_client

    config = CvatConfig.from_env()
    print(f"parsed_timeout={config.request_timeout}")
    configure_data_timeout(config.request_timeout)
    try:
        make_s3_client()
    except ValueError as exc:
        print(f"failure_type={type(exc).__name__}")
        print(f"failure={exc}")
    else:
        raise AssertionError(
            "Negative timeout no longer triggers the reported ValueError"
        )
    assert config.request_timeout == -1.0
