# OPS-001: Cloning substitutes the first task's images into every task

- Severity: Medium (auxiliary cloning helper; source remains intact)
- Status: Reproduced at the orchestration boundary with a deterministic fake; no live cloning performed.
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Expected behavior

The script docstring promises identical labels, tasks and annotations in the cloned project. A project with task 1 containing `a.jpg` and task 2 containing `b.jpg` is a normal supported CVAT image project. The operator guide does explain downloading from the first task, but does not state or validate that every task must contain identical images in identical order.

## Observed behavior and cause

`scripts/clone_project_to_s3.py:313-334` chooses `src_tasks[0]` as the only image source. Lines 336-342 construct one `server_files` list. Lines 360-387 attach that same list to every destination task, while lines 403-418 copy each source task's annotations with original frame indices. The second destination task therefore contains `a.jpg` with annotations intended for `b.jpg`. If sizes differ, frame indices may be invalid as well.

The first-task assumption is visible in an internal comment, not enforced. The script also crashes on an empty source project when indexing `src_tasks[0]`. Natural sorting can further change frame order; that risk has static evidence only and is not independently proven by this reproduction.

## Proof

```bash
uv run --locked python bugs/review-2026-10-03/findings/OPS-001-clone-reuses-first-task-images/reproduce.py
```

See [observed-output.txt](observed-output.txt). The real `main()` runs with isolated fake SDK/network boundaries. Both destination tasks receive `root/destination/a.jpg`; only source task 1 is downloaded. The script asserts the defective observation and exits 0 when reproduced. It does not read real credentials or contact services.

## Impact and future acceptance

The helper can create a plausible but incorrectly annotated clone without reporting failure. A future acceptance check must preserve each task's frame identity and annotation alignment, or explicitly reject projects whose task image sets/order differ before creating any destination objects. Test empty projects and reordered names separately.
