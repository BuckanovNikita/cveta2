"""Run the real cloning orchestration over a small, network-free CVAT fake."""

import importlib.util
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import MagicMock, patch

repo = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "pyproject.toml").exists()
)
spec = importlib.util.spec_from_file_location(
    "clone_review", repo / "scripts/clone_project_to_s3.py"
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
source_tasks = [NS(id=1, name="first", subset=""), NS(id=2, name="second", subset="")]
source = NS(id=1, name="source", get_labels=lambda: [], get_tasks=lambda: source_tasks)
destination = NS(id=2, name="destination", get_labels=lambda: [])
api = MagicMock()
api.retrieve_data_meta.side_effect = lambda ident: (
    NS(frames=[NS(name="a.jpg" if ident == 1 else "b.jpg")], deleted_frames=[]),
    None,
)
api.retrieve_annotations.return_value = (NS(shapes=[], tracks=[]), None)
api.create.side_effect = [(NS(id=10), None), (NS(id=11), None)]
client = MagicMock()
client.projects.list.return_value = [source]
client.projects.retrieve.side_effect = lambda ident: (
    source if ident == 1 else destination
)
client.projects.create.return_value = destination
client.api_client.tasks_api = api
client.api_client.cloudstorages_api.retrieve.return_value = (
    NS(
        id=1,
        resource="bucket",
        specific_attributes="prefix=root&endpoint_url=http%3A%2F%2Fstorage.invalid",
    ),
    None,
)
client.tasks.retrieve.side_effect = lambda ident: NS(
    id=ident, name="destination task", size=1
)
manager = MagicMock()
manager.__enter__.return_value = client
config = NS(
    require_credentials=lambda: NS(
        host="http://cvat.invalid", username="test", password="test", organization=None
    )
)
with (
    patch.object(module.CvatConfig, "load", return_value=config),
    patch.object(module, "make_client", return_value=manager),
    patch.object(module.boto3, "Session"),
    patch.object(
        module, "download_task_frames", return_value={0: b"first-image"}
    ) as download,
    patch.object(module.time, "sleep"),
    patch(
        "sys.argv",
        ["clone_project_to_s3.py", "--source", "source", "--dest", "destination"],
    ),
):
    module.main()
files = [
    call.kwargs["data_request"].server_files for call in api.create_data.call_args_list
]
print("Source task images: [['a.jpg'], ['b.jpg']]")
print("Destination task server_files:", files)
print("Tasks downloaded:", [call.args[1] for call in download.call_args_list])
assert files == [["root/destination/a.jpg"], ["root/destination/a.jpg"]]
assert download.call_count == 1
