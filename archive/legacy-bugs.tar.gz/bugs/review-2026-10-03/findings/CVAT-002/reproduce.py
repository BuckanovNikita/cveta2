"""Reproduce silent omission of a labeled row with an incomplete bbox."""

# Reproduction scripts intentionally print evidence and delay project imports
# until after HOME/config/cache isolation is installed.
# ruff: noqa: INP001, PLC0415, T201

import os
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import MagicMock


def main() -> None:
    """Run the isolated incomplete-bbox upload reproduction."""
    with tempfile.TemporaryDirectory() as isolated:
        os.environ["HOME"] = isolated
        os.environ["XDG_CONFIG_HOME"] = f"{isolated}/config"
        os.environ["XDG_CACHE_HOME"] = f"{isolated}/cache"
        os.environ["CVETA2_CONFIG"] = f"{isolated}/config/cveta2/config.yaml"

        import pandas as pd
        from loguru import logger

        from cveta2._client.ports import CvatApiPort
        from cveta2.client import CvatClient
        from cveta2.config import CvatConfig
        from cveta2.models import LabelInfo

        logger.remove()
        logger.add(sys.stdout, format="{message}", level="INFO")

        api = MagicMock(spec=CvatApiPort)
        client = CvatClient(CvatConfig(), api=api)
        session = SimpleNamespace(
            name_to_frame={"broken.jpg": 0},
            labels=[LabelInfo(id=7, name="car")],
        )
        rows = pd.DataFrame(
            [
                {
                    "image_name": "broken.jpg",
                    "instance_shape": "box",
                    "instance_label": "car",
                    "bbox_x_tl": 1.0,
                    "bbox_y_tl": 2.0,
                    "bbox_x_br": 30.0,
                    "bbox_y_br": None,
                }
            ]
        )

        uploaded = client.upload_task_annotations(99, rows, session=session)
        print(f"source_labeled_rows={int(rows['instance_label'].notna().sum())}")
        print(f"uploaded_shapes={uploaded}")
        print(f"put_called={api.put_task_shapes.called}")
        assert uploaded == 0 and not api.put_task_shapes.called


if __name__ == "__main__":
    main()
