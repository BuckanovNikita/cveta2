# CVAT-002 — Incomplete labeled boxes are silently omitted during upload

- Severity: Medium
- Status: Reproduced
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Expected

A row declared as a box with a label but missing one or more bbox coordinates must stop validation or produce an explicit skip warning that identifies the affected row/image. It must not be reported as if the input contained no annotations.

## Actual

`build_upload_shapes()` excludes incomplete labeled rows in its initial boolean mask without recording why. `upload_task_annotations()` warns for unknown images and labels only. When every labeled row is incomplete, it logs `Нет аннотаций для загрузки` and returns success with zero uploaded shapes.

## Reproduction

```bash
uv run --locked python bugs/review-2026-10-03/findings/CVAT-002/reproduce.py
```

Observed output:

```text
Нет аннотаций для загрузки в задачу 99
source_labeled_rows=1
uploaded_shapes=0
put_called=False
```

## Code evidence

- `cveta2/_client/assembly.py:131-135` filters incomplete coordinates out before the diagnostic result is built.
- `cveta2/_client/assembly.py:138-143` records only unknown images and unknown labels.
- `cveta2/_client_ops/write.py:246-255` has warnings only for those two recorded reasons.
- `cveta2/_client_ops/write.py:257-267` treats the resulting empty list as a normal no-annotation upload.

The issue-upload path already records and warns about missing bboxes; annotation upload lacks the equivalent guard.

## Impact

A damaged or partially edited CSV can create a CVAT task successfully while silently losing bbox annotations. The success path removes the upload manifest, so `--resume` cannot repair the omitted rows.

## Future acceptance assertion

Given an `instance_shape="box"` row with a non-empty `instance_label` and any missing bbox coordinate, upload fails before creating shapes (preferred) or emits a row/image-specific warning and a non-success/degraded result; a genuinely unannotated row remains valid.
