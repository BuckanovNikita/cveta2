# DATA-004: repeat COCO export retains removed splits and images

- Severity: Unrated pending the output-directory contract decision
- Status: Unclear contract; stale-output observation reproduced
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`
- Historical relationship: new finding; no production changes made.

## Expected behavior and contract

`convert_to_coco()` reports that the COCO dataset was saved at the requested output directory, but the documentation does not say whether a repeat run replaces that dataset or incrementally updates only current splits. A product decision is required before classifying stale split cleanup as mandatory.

## Observed behavior and cause

The exporter creates and writes only the splits present in the current frame. It never removes split directories, JSON files, or images from a previous run. After a first `train+val` export and a second `train`-only export, `valid/_annotations.coco.json` still declares the removed image and the image file remains.

Source evidence: `cveta2/services/convert/coco.py:123-145` (line numbers at the reviewed commit). YOLO has an explicit `_prune_yolo_output()` step; COCO has no equivalent.

## Impact

If the directory is intended to represent the current CSV, consumers that scan it can train or evaluate on images removed from the current dataset. The stale JSON is internally valid, so the mismatch is silent. Under intentional incremental semantics, the same observation needs explicit documentation so callers know to clean or choose a fresh directory.

## Reproduction

Run from the repository root:

```bash
uv run --locked python bugs/review-2026-10-03/findings/DATA-004/reproduce.py
```

The script uses an isolated temporary home and asserts the stale split contents after the second export. See [observed output](observed-output.txt).

## Future acceptance assertion

First decide and document whether repeat COCO export is replacement or incremental. For replacement semantics, export `train+val`, then a `train`-only CSV to the same directory and assert `valid/` plus its removed image are absent. For incremental semantics, document that stale splits remain and provide a clear fresh-output/cleanup workflow (or an explicit mode) with coverage that pins the chosen behavior.
