"""Reproduce stale COCO split artifacts after a repeat export."""

import json
import os
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory(prefix="cveta2-data-004-") as temporary:
    root = Path(temporary)
    os.environ["HOME"] = str(root / "home")
    os.environ["XDG_CACHE_HOME"] = str(root / "cache")
    os.environ["XDG_CONFIG_HOME"] = str(root / "config")

    import pandas as pd
    from loguru import logger
    from PIL import Image

    from cveta2.models import CSV_COLUMNS
    from cveta2.services.convert import convert_to_coco

    logger.remove()

    source = root / "source"
    source.mkdir()
    for name, color in (("a.png", "red"), ("b.png", "blue")):
        Image.new("RGB", (8, 8), color=color).save(source / name)

    def row(name: str, split: str) -> dict[str, object]:
        value = dict.fromkeys(CSV_COLUMNS, None)
        value.update(
            image_name=name,
            image_width=8,
            image_height=8,
            instance_shape="none",
            split=split,
        )
        return value

    csv_path = root / "dataset.csv"
    output = root / "coco"
    pd.DataFrame(
        [row("a.png", "train"), row("b.png", "val")], columns=CSV_COLUMNS
    ).to_csv(csv_path, index=False)
    convert_to_coco(csv_path, output, image_dirs=[source], link_mode="copy")

    pd.DataFrame([row("a.png", "train")], columns=CSV_COLUMNS).to_csv(
        csv_path, index=False
    )
    convert_to_coco(csv_path, output, image_dirs=[source], link_mode="copy")

    stale_json = output / "valid" / "_annotations.coco.json"
    stale_images = []
    if stale_json.is_file():
        data = json.loads(stale_json.read_text(encoding="utf-8"))
        stale_images = [item["file_name"] for item in data["images"]]
    print("second input splits:", ["train"])
    print("valid directory remains:", (output / "valid").is_dir())
    print("stale valid JSON images:", stale_images)
    print("stale b.png remains:", (output / "valid" / "b.png").is_file())
    assert stale_images == ["b.png"]
    assert (output / "valid" / "b.png").is_file()
