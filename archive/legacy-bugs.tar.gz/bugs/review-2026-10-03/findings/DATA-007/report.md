# DATA-007: YOLO import accepts non-integral classes and non-finite coordinates

- Severity: Medium
- Status: Reproduced
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`
- Historical relationship: new finding; no production changes made.

## Expected behavior and contract

YOLO detection rows use an integer class id followed by finite normalized coordinates. The parser's documented degraded behavior skips malformed lines with a warning; imported `box` rows must contain usable bbox coordinates.

## Observed behavior and cause

`_parse_label_file()` accepts any token Python `float()` accepts, including fractional class ids and `nan`/`inf`. `_yolo_fields_to_row()` truncates the class through `int(fields[0])`; `1.9` silently becomes class 1. A `nan` coordinate propagates through conversion and pandas writes it as an empty bbox cell in a row still marked `instance_shape=box`. No warning is emitted.

Source evidence: `cveta2/services/convert/yolo.py:235-259,287-302`; `cveta2/services/convert/common.py:79-85,314-349` (line numbers at the reviewed commit).

## Impact

Malformed prediction or dataset labels can silently acquire the wrong class or become structurally invalid CSV annotations. Downstream upload/export may then fail later or consume incorrect labels without tying the error to the source line.

## Reproduction

Run from the repository root:

```bash
uv run --locked python bugs/review-2026-10-03/findings/DATA-007/reproduce.py
```

The script uses an isolated temporary home and asserts both corrupt outputs. See [observed output](observed-output.txt).

## Future acceptance assertion

Import label rows containing a fractional/negative class id and `nan`/`inf` coordinates or confidence; assert each invalid row is rejected or skipped with a file-and-line warning, no malformed box row is written, and valid sibling rows still convert.
