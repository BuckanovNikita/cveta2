"""Reproduce semantic corruption from invalid numeric YOLO fields."""

import os
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory(prefix="cveta2-data-007-") as temporary:
    root = Path(temporary)
    os.environ["HOME"] = str(root / "home")
    os.environ["XDG_CACHE_HOME"] = str(root / "cache")
    os.environ["XDG_CONFIG_HOME"] = str(root / "config")

    import pandas as pd
    from loguru import logger
    from PIL import Image

    from cveta2.services.convert import convert_from_yolo

    logger.remove()

    predictions = root / "predictions"
    (predictions / "images").mkdir(parents=True)
    Image.new("RGB", (10, 10), color="white").save(predictions / "images" / "a.png")
    (predictions / "a.txt").write_text(
        "1.9 0.5 0.5 0.2 0.2\n0 nan 0.5 0.2 0.2\n",
        encoding="utf-8",
    )
    names = root / "names.yaml"
    names.write_text("names: [cat, dog]\n", encoding="utf-8")
    output = root / "output.csv"
    convert_from_yolo(
        predictions,
        output,
        names_file=names,
        read_all_sizes=True,
    )
    frame = pd.read_csv(output)
    print("output rows:", len(frame))
    print("labels:", frame["instance_label"].tolist())
    print("first fractional class became:", frame.loc[0, "instance_label"])
    print("second bbox_x_tl is missing:", pd.isna(frame.loc[1, "bbox_x_tl"]))
    assert frame["instance_label"].tolist() == ["dog", "cat"]
    assert pd.isna(frame.loc[1, "bbox_x_tl"])
