#!/usr/bin/env bash
# Run from a disposable checkout root; this runs the configured mutation gate.
bash scripts/mutation_test.sh --profile review-does-not-exist --max-children 8
