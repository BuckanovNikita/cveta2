# OPS-003: An invalid mutation profile prints an error but exits successfully

- Severity: Low (tooling configuration/error handling)
- Status: Reproduced with the actual configured full-scope mutation gate in a disposable checkout.
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Expected behavior

An undefined `--profile` is invalid configuration. `mutation_config.profile_globs()` explicitly exits with an error for unknown names. The wrapper should preserve that failure rather than silently use a different scope.

## Actual behavior and cause

`scripts/mutation_test.sh:63-69` reads profile globs through process substitution. The child Python process fails, but Bash's `while ... done < <(...)` does not propagate that exit status into `set -e`. The empty glob list causes an unrestricted full-scope run, and the gate receives the invalid profile only as a display label. In this reviewed checkout it prints `Unknown mutation profile ...`, then runs the full gate and exits 0.

## Proof

From a disposable checkout with the locked development dependencies:

```bash
bash bugs/review-2026-10-03/findings/OPS-003-invalid-mutation-profile/reproduce.sh
```

The wrapper script must also be copied into that checkout, or invoke its command directly. This can take the time of a full mutation run when no cache exists. [Observed output](observed-output.txt) and [command/exit record](../../evidence/check-logs/mutation-invalid-profile.result.json) preserve the actual run. No fixture or fake generated this result.

## Impact and future acceptance

A mistyped or malformed profile appears to succeed under a different test scope and can unexpectedly run expensive full checks. This is not a demonstrated false-green application gate: the observed fallback ran the entire configured scope. Assert an unknown profile exits nonzero before mutmut starts, while defined empty `full` continues to mean the full scope.
