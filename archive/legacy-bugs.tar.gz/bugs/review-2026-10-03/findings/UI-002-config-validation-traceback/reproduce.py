"""Reproduce a typed configuration error escaping as a traceback."""

# ruff: noqa: I001, INP001, T201

import os
import subprocess
import sys
import tempfile
from pathlib import Path


with tempfile.TemporaryDirectory(prefix="cveta2-ui-002-") as raw_tmp:
    tmp = Path(raw_tmp)
    home = tmp / "home"
    home.mkdir()
    config = tmp / "config.yaml"
    config.write_text("cvat:\n  host: []\n", encoding="utf-8")
    env = os.environ.copy()
    env.update(
        {
            "HOME": str(home),
            "XDG_CACHE_HOME": str(tmp / "xdg-cache"),
            "CVETA2_CONFIG": str(config),
            "AWS_EC2_METADATA_DISABLED": "true",
        }
    )
    completed = subprocess.run(
        [sys.executable, "-m", "cveta2", "doctor"],
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )
    print(f"returncode={completed.returncode}")
    has_traceback = "Traceback (most recent call last)" in completed.stderr
    print(f"contains_traceback={has_traceback}")
    print(f"contains_validation_error={'ValidationError' in completed.stderr}")
    print("stderr_tail=")
    print("\n".join(completed.stderr.splitlines()[-8:]))
    assert completed.returncode == 1
    assert has_traceback and "ValidationError" in completed.stderr
