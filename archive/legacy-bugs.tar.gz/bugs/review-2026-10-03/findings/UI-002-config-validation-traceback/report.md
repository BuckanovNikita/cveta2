# UI-002 — Typed configuration errors bypass the CLI error boundary

- Severity: Low (configuration diagnostic/error boundary)
- Status: Reproduced
- Commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`
- Historical disposition: BR-08's YAML parser failure is fixed, but the same
  accepted disposition explicitly called for equivalent Pydantic validation
  handling; that half remains exposed.

## Expected contract

The CLI boundary converts every `Cveta2Error` into a concise message
(`cveta2/cli.py:688-699`), and the architecture requires failures above the
client layer to use that domain hierarchy. A syntactically valid YAML file
whose typed value is invalid should name the file/field without a Python
traceback, just as malformed YAML now does (`cveta2/config.py:92-103`).

## Actual observation

`CvatConfig._from_cvat_section()` constructs the Pydantic model directly
(`cveta2/config.py:226-232`). `SectionConfig.load()` does the same for every
other section (`cveta2/config.py:164-170`). Neither translates
`pydantic.ValidationError` to `Cveta2Error`, so `cveta2 doctor` with
`cvat.host: []` escapes the CLI handler as a traceback.

Command:

```text
uv run --locked python bugs/review-2026-10-03/findings/UI-002-config-validation-traceback/reproduce.py
```

Observed output:

```text
returncode=1
contains_traceback=True
contains_validation_error=True
stderr_tail=
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/mnt/wsl/data/nkt/cveta2/.venv/lib/python3.12/site-packages/pydantic/main.py", line 250, in __init__
    validated_self = self.__pydantic_validator__.validate_python(data, self_instance=self)
                     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
pydantic_core._pydantic_core.ValidationError: 1 validation error for CvatConfig
host
  Input should be a valid string [type=string_type, input_value=[], input_type=list]
    For further information visit https://errors.pydantic.dev/2.12/v/string_type
```

## Impact

Typos in any validated connection, upload, network, cache, or ClearML value
can expose internal stack frames and omit the configuration path. This is the
same user-facing failure class as malformed YAML, but behaves differently
depending on whether parsing or model validation detects it.

## Future acceptance assertion

Running a CLI command with syntactically valid but type-invalid configuration
exits nonzero with one `Cveta2Error` message containing the config path and
failing field; stderr contains no `Traceback` or raw `ValidationError`.

## Captured proof

The parent reran the reproduction independently. See [observed output](observed-output.txt) and the shared [reproduction results](../../evidence/reproduction-results.json). Exit 0 indicates the defective observation was reproduced, not that the intended behavior passed.
