"""Observe doctor exit status when isolated local health checks fail."""

import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

with TemporaryDirectory() as tmp:
    root = Path(tmp)
    env = os.environ.copy()
    for key in list(env):
        if key.startswith(("CVAT_", "AWS_")):
            env.pop(key)
    env.update(
        {
            "HOME": str(root),
            "XDG_CACHE_HOME": str(root / "cache"),
            "CVETA2_CONFIG": str(root / "missing.yaml"),
            "AWS_EC2_METADATA_DISABLED": "true",
            "AWS_SHARED_CREDENTIALS_FILE": str(root / "missing-aws"),
            "AWS_CONFIG_FILE": str(root / "missing-aws-config"),
        }
    )
    result = subprocess.run(
        [sys.executable, "-m", "cveta2", "doctor"],
        env=env,
        capture_output=True,
        text=True,
    )
    print("CLI exit status:", result.returncode)
    print("Failed-health summary present:", "some checks failed" in result.stderr)
    print("Missing credentials reported:", "No credentials" in result.stderr)
    assert result.returncode == 0
    assert "some checks failed" in result.stderr and "No credentials" in result.stderr
