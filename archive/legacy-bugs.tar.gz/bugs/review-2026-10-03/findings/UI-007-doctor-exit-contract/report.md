# UI-007: Doctor's exit status does not express the health-check result

- Severity: Unrated pending the automation contract
- Status: Unclear contract; end-to-end CLI observation reproduced
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Observation and source evidence

`cveta2/commands/doctor.py:36-51` aggregates failed checks but only logs a final warning. It returns normally, so the CLI exits 0 even when configuration and AWS credentials are missing. The operator guide (`docs/cli.md:486-498`) describes diagnostics but does not state whether the exit status represents successful execution or healthy configuration.

```bash
uv run --locked python bugs/review-2026-10-03/findings/UI-007-doctor-exit-contract/reproduce.py
```

See [observed output](observed-output.txt). The script runs the actual CLI with temporary config/cache/home and disabled AWS metadata; it neither contacts CVAT nor repairs permissions. Assertions establish the zero exit alongside explicit failed checks.

## Review decision needed

This is not counted as a confirmed defect: human-oriented diagnostics can intentionally return 0 after a completed check. Automation cannot use the exit status as a health signal under current behavior. Decide and document whether doctor should expose aggregate health via exit status (or another explicit interface), including warning-only and partially checked states. A future acceptance check should encode that selected contract; do not change behavior based only on this report.
