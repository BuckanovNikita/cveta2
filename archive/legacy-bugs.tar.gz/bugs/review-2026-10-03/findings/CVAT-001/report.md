# CVAT-001 — Duplicate task and project names resolve to arbitrary targets

- Severity: High
- Status: Reproduced
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Expected

A task or project name that matches multiple objects in the active scope must be rejected as ambiguous and identify the matching IDs. A numeric ID must remain an unambiguous selector. This is especially important for `task delete`, `task drop-label`, `task mark-deleted`, and `task status`.

## Actual

`_resolve_one_task_selector()` returns the first case-insensitive task-name match. `find_project_by_name()` also returns the first matching cached or live project. Reversing the project task-list order changes the selected task. `resolved_task()` uses this resolver for mutation commands, so an explicit duplicate name can mutate or delete a different task than the caller intended.

## Reproduction

```bash
uv run --locked python bugs/review-2026-10-03/findings/CVAT-001/reproduce.py
```

Observed output:

```text
forward_selected=11
reverse_selected=22
order_dependent=True
forward_project=101
reverse_project=202
project_order_dependent=True
```

## Code evidence

- `cveta2/_client_ops/fetch.py:194-203` returns immediately on the first name match and never checks for a second match.
- `cveta2/_client_ops/fetch.py:219-225` treats that single result as resolved.
- `cveta2/services/task_ops.py:39-40` routes task mutations through the same resolver.
- `cveta2/_client_ops/read.py:137-144` returns the first project name match in cached or live lists.

CVAT permits duplicate task names, and ordinary uploads can create another task with the same name. The list order is therefore not a safe identity rule.

## Impact

Name-based fetches can return the wrong task. More seriously, name-based maintenance can alter job state, delete annotations, mark frames deleted, or permanently delete the wrong task. A confirmation that repeats the duplicate name cannot disambiguate the target.

## Future acceptance assertion

Given two tasks named `duplicate` with IDs 11 and 22, resolving `duplicate` raises a domain error that lists both IDs and performs no read or write against either task; resolving `11` still selects task 11.

## Project-selector validation boundary

The same first-match behavior exists in `cveta2/_client_ops/read.py:137-144` for project names, both in the local cache and live project listing. The reproduction also reverses a cached pair of projects named `same-project`: IDs 101 and 202 are returned respectively. This establishes the shared cached-name behavior without contacting CVAT. Project names have no documented uniqueness precondition; the live-test helper explicitly rejects duplicate project names (`tests/integration/conftest.py:81-95`).

Name-based upload, label updates/deletion, and task maintenance can consequently target the wrong project as well. The shared finding covers both selectors; it does not assert that the task-level code alone fixes project resolution. A future acceptance assertion must reject ambiguous project names and preserve numeric-ID targeting.
