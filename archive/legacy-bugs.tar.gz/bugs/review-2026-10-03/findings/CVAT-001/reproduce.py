"""Reproduce order-dependent resolution of duplicate CVAT task and project names."""

# Reproduction scripts intentionally print evidence and delay project imports
# until after HOME/config/cache isolation is installed.
# ruff: noqa: INP001, PLC0415, T201

import os
import tempfile


def main() -> None:
    """Run the isolated duplicate-name selector reproduction."""
    with tempfile.TemporaryDirectory() as isolated:
        os.environ["HOME"] = isolated
        os.environ["XDG_CONFIG_HOME"] = f"{isolated}/config"
        os.environ["XDG_CACHE_HOME"] = f"{isolated}/cache"
        os.environ["CVETA2_CONFIG"] = f"{isolated}/config/cveta2/config.yaml"

        from cveta2.client import CvatClient
        from cveta2.models import ProjectInfo, TaskInfo
        from cveta2.config import CvatConfig

        first = TaskInfo(
            id=11,
            name="duplicate",
            status="annotation",
            subset="",
            updated_date="2026-10-01T00:00:00Z",
            project_id=7,
        )
        second = first.model_copy(update={"id": 22})

        forward = CvatClient.resolve_task_selectors([first, second], ["duplicate"])
        reverse = CvatClient.resolve_task_selectors([second, first], ["duplicate"])
        print(f"forward_selected={forward[0].id}")
        print(f"reverse_selected={reverse[0].id}")
        print(f"order_dependent={forward[0].id != reverse[0].id}")
        assert forward[0].id != reverse[0].id
        projects = [
            ProjectInfo(id=101, name="same-project"),
            ProjectInfo(id=202, name="same-project"),
        ]
        client = CvatClient(CvatConfig(host="http://cvat.invalid"))
        first_project = client.find_project_by_name("same-project", cached=projects)
        second_project = client.find_project_by_name(
            "same-project", cached=list(reversed(projects))
        )
        print(f"forward_project={first_project.id}")
        print(f"reverse_project={second_project.id}")
        print(f"project_order_dependent={first_project.id != second_project.id}")
        assert first_project.id != second_project.id


if __name__ == "__main__":
    main()
