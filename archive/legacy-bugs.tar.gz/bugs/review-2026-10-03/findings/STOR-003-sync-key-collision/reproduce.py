import io
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from cveta2.image_downloader import CloudStorageInfo, S3Syncer


class Storage:
    def list_objects_v2(self, **kwargs):
        return {"Contents": [{"Key": "root//a.jpg"}, {"Key": "root/a.jpg"}]}

    def get_object(self, **kwargs):
        return {"Body": io.BytesIO(kwargs["Key"].encode())}


with TemporaryDirectory() as tmp:
    destination = Path(tmp)
    with patch("cveta2.image_downloader.make_s3_client", return_value=Storage()):
        stats = S3Syncer(destination).sync(
            CloudStorageInfo(id=1, bucket="test-bucket", prefix="root", endpoint_url="")
        )
    files = [path.name for path in destination.iterdir()]
    print("Reported:", stats.model_dump())
    print("Files:", files)
    print("Surviving content:", (destination / "a.jpg").read_text())
    assert stats.downloaded == 2 and files == ["a.jpg"]
