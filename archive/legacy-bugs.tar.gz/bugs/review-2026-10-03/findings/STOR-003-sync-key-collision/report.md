# STOR-003-sync-key-collision: S3 sync collapses distinct leading-separator keys into one file

- Severity: Unrated pending S3-sync scope clarification
- Status: Unclear contract; normalization collision reproduced outside the guaranteed unique-basename input domain
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`
- Historical relationship: new finding; no production changes made.

## Expected behavior and contract

strip_key_prefix explicitly preserves doubled separators because they identify distinct S3 objects. Safe path validation rejects empty path components, but the subsequent lstrip bypasses that rejection for the first component. The internal S3Syncer docstring says it processes all objects, while public image contracts require unique basenames/stems. Whether raw key fidelity extends beyond supported image inputs is unresolved.

## Observed behavior and cause

Under prefix root, root//a.jpg and root/a.jpg both map to local a.jpg because _local_name_from_key strips all leading slashes after strip_key_prefix. Sync reports two downloads and zero failures but leaves only one object. Parallel workers can race over that destination.

Source evidence: `cveta2/image_downloader.py:137-141,467-484; cveta2/s3_utils.py:272-289` (line numbers at the reviewed commit).

## Impact

A legal S3 key with a doubled separator can lose its content locally while the summary reports complete success. The reproduction supplies two images sharing a basename, which is outside the documented distinct-image input contract. It does not establish a supported-input data-loss defect. The exact-key mapping and internal preservation comment nevertheless leave raw S3-sync behavior unclear.

## Reproduction

Run from the repository root, using the locked development environment:

```bash
uv run --locked python bugs/review-2026-10-03/findings/STOR-003-sync-key-collision/reproduce.py
```

The script asserts the current defective observation and exits 0 when reproduced. It uses temporary files or an in-memory S3 boundary; it makes no network calls. See [observed output](observed-output.txt).

## Future acceptance assertion

List both keys and assert sync either rejects the noncanonical key before writes or preserves both identities, with truthful counts. Repeat with multiple workers.

## Independent review disposition

Excluded from confirmed bug totals. No accepted BR-03/BR-05 behavior is reopened. Public docs state that cache layout mirrors S3 (`docs/images-and-cache.md:27`), but no explicit general-purpose raw-object fidelity contract was established for unsupported duplicate image basenames. Decide whether S3 sync enforces image-input restrictions, rejects noncanonical keys, or guarantees raw-key fidelity; only then classify a defect and choose severity.
