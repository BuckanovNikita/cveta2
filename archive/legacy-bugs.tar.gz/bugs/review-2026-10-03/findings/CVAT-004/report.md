# CVAT-004 — Manifest cleanup failure escapes after remote upload succeeds

- Severity: Medium
- Status: Component-reproduced; post-upload call path statically validated
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Expected

Failure to remove recovery bookkeeping after all CVAT writes complete must be handled as a warning or translated into an actionable domain error that states the remote task succeeded. The command must not end with an unclassified filesystem exception and an apparently resumable stale manifest.

## Actual

Manifest creation catches `OSError` and warns, but manifest deletion calls `Path.unlink()` without handling it. `upload_dataset()` deletes the manifest only after task creation, annotation/issue upload, deleted-frame updates, and optional completion. A permission or shared-cache filesystem error therefore turns a completed remote upload into a local exception and leaves the manifest behind.

## Reproduction

```bash
uv run --locked python bugs/review-2026-10-03/findings/CVAT-004/reproduce.py
```

Observed output:

```text
exists_before=True
raised=PermissionError
exists_after=True
```

## Code evidence

- `cveta2/upload_manifest.py:94-106` explicitly contains save-side `OSError` handling.
- `cveta2/upload_manifest.py:145-148` performs cleanup with an unguarded `unlink()`.
- `cveta2/services/upload.py:572-575` calls cleanup after all remote stages and before normal outcome reporting/cache invalidation.

## Impact

The user sees a failed command even though the CVAT task was fully mutated. The stale manifest continues to advertise a resumable upload, and every later resume reaches the same cleanup failure until cache permissions are repaired. Automation receives an exception type outside the service's `Cveta2Error` contract.

## Future acceptance assertion

After a successful remote upload, force manifest unlink to raise `PermissionError`; assert the outcome clearly reports the created task and the cleanup problem is handled without an unclassified traceback or false implication that remote writes failed.
