"""Reproduce an unhandled permission error while deleting a manifest."""

# Reproduction scripts intentionally print evidence and delay project imports
# until after HOME/config/cache isolation is installed.
# ruff: noqa: INP001, PLC0415, T201

import os
import tempfile


def main() -> None:
    """Run the isolated manifest-cleanup permission reproduction."""
    with tempfile.TemporaryDirectory() as isolated:
        os.environ["HOME"] = isolated
        os.environ["XDG_CONFIG_HOME"] = f"{isolated}/config"
        os.environ["XDG_CACHE_HOME"] = f"{isolated}/cache"
        os.environ["CVETA2_CONFIG"] = f"{isolated}/config/cveta2/config.yaml"

        from cveta2.image_downloader import CloudStorageInfo
        from cveta2.upload_manifest import (
            delete_manifest,
            get_upload_manifest_dir,
            new_manifest,
            save_manifest,
        )

        manifest = new_manifest(
            "dataset.csv",
            "fingerprint",
            7,
            "task",
            CloudStorageInfo(
                id=1,
                bucket="bucket",
                prefix="prefix",
                endpoint_url="http://s3.invalid",
            ),
            {"a.jpg": "a.jpg"},
            ["prefix/a.jpg"],
            host="http://cvat.invalid",
        )
        save_manifest(manifest)
        directory = get_upload_manifest_dir(7, host=manifest.host)
        path = directory / "fingerprint.json"
        print(f"exists_before={path.exists()}")
        assert path.exists()

        directory.chmod(0o500)
        try:
            delete_manifest(7, "fingerprint", host=manifest.host)
        except PermissionError as error:
            print(f"raised={type(error).__name__}")
        else:
            raise AssertionError("Manifest deletion no longer leaks PermissionError")
        finally:
            directory.chmod(0o700)
        print(f"exists_after={path.exists()}")
        assert path.exists()


if __name__ == "__main__":
    main()
