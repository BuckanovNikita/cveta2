# CVAT-005 — `503 Retry-After` replays non-idempotent CVAT writes

- Severity: High
- Status: Reproduced with an ambiguous-write fake; no live CVAT write was performed
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Expected

A non-idempotent write must be retried only when the response proves the server did not apply it. `503 Service Unavailable`, with or without `Retry-After`, does not prove non-application; the header specifies when to retry, not whether the first request committed. An ambiguous result must stop and use read-back/resume reconciliation.

## Actual

`_should_retry_write()` returns true for every `CvatApiError(status_code=503)` carrying any `retry_after` value. The shared decorator is applied to task creation, data attachment, CREATE-mode shape upload, and issue creation. A server/proxy path that applies the request and then returns 503 with `Retry-After` executes the remote mutation again.

## Reproduction

```bash
uv run --locked python bugs/review-2026-10-03/findings/CVAT-005/reproduce.py
```

Observed output (the warning line is produced by the real retry wrapper):

```text
predicate_retries_503=True
... ambiguous-write call failed (attempt 1), retrying ...
remote_effect_count=2
```

## Code evidence

- `cveta2/_client/sdk_adapter.py:131-146` treats `503` plus `Retry-After` as proof that a write was refused.
- `cveta2/_client/sdk_adapter.py:425-427`, `468-470`, `493-495`, and `504-506` apply that policy to task creation, data attachment, shape creation, and issue creation.
- `docs/configuration.md:128-130` acknowledges that CVAT writes append and that a 5xx can arrive after application, but carves out the same unsafe `503` case without an application-level idempotency key or read-back check.

The reproduction models the permitted ambiguous outcome: the remote effect happens before the client receives the 503. The retry mechanism then applies the effect twice.

## Impact

One transient 503 can create duplicate tasks, append a second copy of every bbox, or duplicate issues. The later `--resume` logic cannot remove duplicates already created by the automatic retry because the retry returns success and the manifest is deleted.

## Future acceptance assertion

Simulate a create/append call that records its remote effect and then raises `CvatApiError(503, retry_after=...)`; assert exactly one remote effect, the call surfaces as ambiguous, and the normal resume/read-back path decides what to do next.

## Protocol source and confidence

[RFC 9110, section 9.2.2](https://www.rfc-editor.org/rfc/rfc9110.html#name-idempotent-methods) restricts automatic retries of non-idempotent requests to cases with application-specific safety or evidence that the original request was not applied. [Section 10.2.3](https://www.rfc-editor.org/rfc/rfc9110.html#name-retry-after) defines Retry-After as timing guidance. Inferring duplicate effects in a CVAT deployment requires a post-application 503 response from its application/proxy path; this review did not observe that failure on the live stand. The fake establishes the client behavior under that condition, not its incidence.
