"""Reproduce replay of an ambiguously successful write on HTTP 503."""

# Reproduction scripts intentionally print evidence and delay project imports
# until after HOME/config/cache isolation is installed.
# ruff: noqa: INP001, PLC0415, T201

import os
import tempfile


def main() -> None:
    """Run the isolated ambiguous-write retry reproduction."""
    with tempfile.TemporaryDirectory() as isolated:
        os.environ["HOME"] = isolated
        os.environ["XDG_CONFIG_HOME"] = f"{isolated}/config"
        os.environ["XDG_CACHE_HOME"] = f"{isolated}/cache"
        os.environ["CVETA2_CONFIG"] = f"{isolated}/config/cveta2/config.yaml"

        from cveta2._client.sdk_adapter import _should_retry_write
        from cveta2._retry import configure_retries, network_retry
        from cveta2.exceptions import CvatApiError

        configure_retries(2, 0.0)
        effects: list[str] = []

        @network_retry(_should_retry_write, label="ambiguous-write")
        def write() -> None:
            effects.append("server applied write")
            if len(effects) == 1:
                raise CvatApiError(
                    "503 returned after upstream applied the request",
                    status_code=503,
                    retry_after=0.0,
                )

        error = CvatApiError("service unavailable", status_code=503, retry_after=1.0)
        print(f"predicate_retries_503={_should_retry_write(error)}")
        write()
        print(f"remote_effect_count={len(effects)}")
        assert len(effects) == 2 and _should_retry_write(error)


if __name__ == "__main__":
    main()
