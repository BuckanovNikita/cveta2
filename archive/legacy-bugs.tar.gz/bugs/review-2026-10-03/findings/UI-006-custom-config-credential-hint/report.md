# UI-006 — Missing-credential errors name the ambient config instead of `Connection.config_path`

- Severity: Low
- Status: Reproduced
- Commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Expected contract

`Connection.config_path` selects the file used by a public API call
(`cveta2/api.py:143-159`; `docs/python-api.md:72-86`). When credentials are
missing from that selected profile, the error should direct the caller to the
same file.

## Actual observation

`_open()` correctly loads `conn.config_path` (`cveta2/api.py:179-187`), but
`CvatConfig.require_credentials()` formats its hint with a fresh
parameterless `get_config_path()` call (`cveta2/config.py:303-319`). That call
resolves `CVETA2_CONFIG` or the default path, losing the explicit path that was
actually loaded.

Command:

```text
uv run --locked python bugs/review-2026-10-03/findings/UI-006-custom-config-credential-hint/reproduce.py
```

Observed output (temporary-directory suffix varies):

```text
failure_type=MissingCredentialsError
selected_path_mentioned=False
ambient_path_mentioned=True
failure=Учётные данные CVAT не настроены. Задайте CVAT_USERNAME и CVAT_PASSWORD или заполните cvat.username/password в /tmp/cveta2-ui-006-hrdw1d1b/ambient.yaml.
```

## Impact

Multi-profile API callers are told to edit a file that the failing call did
not read. Fixing the named file leaves the operation broken and can expose or
mix credentials across profiles.

## Future acceptance assertion

With `CVETA2_CONFIG` pointing to A and `Connection(config_path=B)`, a
missing-credentials exception mentions B and does not mention A; the same rule
holds for direct `CvatClient` construction from a path-aware load result.

## Captured proof

The parent reran the reproduction independently. See [observed output](observed-output.txt) and the shared [reproduction results](../../evidence/reproduction-results.json). Exit 0 indicates the defective observation was reproduced, not that the intended behavior passed.
