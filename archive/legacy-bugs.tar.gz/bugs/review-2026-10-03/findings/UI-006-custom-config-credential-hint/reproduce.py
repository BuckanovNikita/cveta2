"""Reproduce a custom profile error naming the ambient config path."""

# ruff: noqa: I001, INP001, T201

import os
import tempfile
from pathlib import Path


with tempfile.TemporaryDirectory(prefix="cveta2-ui-006-") as raw_tmp:
    tmp = Path(raw_tmp)
    os.environ["HOME"] = str(tmp / "home")
    os.environ["XDG_CACHE_HOME"] = str(tmp / "xdg-cache")
    ambient = tmp / "ambient.yaml"
    selected = tmp / "selected.yaml"
    os.environ["CVETA2_CONFIG"] = str(ambient)
    selected.write_text("cvat:\n  host: https://cvat.example\n", encoding="utf-8")

    from cveta2.api import Connection, _open
    from cveta2.exceptions import MissingCredentialsError

    try:
        with _open(Connection(config_path=selected)):
            pass
    except MissingCredentialsError as exc:
        message = str(exc)
        print(f"failure_type={type(exc).__name__}")
        print(f"selected_path_mentioned={str(selected) in message}")
        print(f"ambient_path_mentioned={str(ambient) in message}")
        print(f"failure={message}")
        assert str(ambient) in message and str(selected) not in message
    else:
        raise AssertionError("Expected MissingCredentialsError")
