# OPS-002: The dataset upload helper silently misassigns or drops class IDs

- Severity: Medium
- Status: Reproduced through actual main() with real YAML, YOLO and image inputs and fake remote services; no live CVAT mutation performed.
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Expected behavior

The operator helper describes YAML `names` as a class-ID-to-name mapping. A declared class should map to that ID's name. Invalid negative class IDs must not become annotations of a different class. Sparse IDs are accepted by the model without a contiguous-ID restriction; if unsupported, they need rejection before remote creation.

## Observed behavior and cause

`scripts/upload_dataset_to_cvat.py:50-59` sorts names into a dense list, discarding the actual IDs. Lines 130-137 accept `-1` as a parsed YOLO class ID. Lines 284-292 check only the upper bound and then index `label_ids_by_class[class_id]`.

`-1` therefore selects the last project label. A sparse map `{0: first, 2: third}` validates, but annotations for the declared class `2` are silently skipped because the generated label list has length 2. Other gaps can also select the wrong class. A negative ID beyond the list's length raises IndexError after remote objects have already been created.

## Proof

```bash
uv run --locked python bugs/review-2026-10-03/findings/OPS-002-yolo-class-index-misassignment/reproduce.py
```

See [observed-output.txt](observed-output.txt). The reproduction calls the actual `main()` twice with real temporary YAML/YOLO/image files and injected CVAT services. It captures the shapes handed to `update_annotations`: negative class -1 uploads label 20, while declared sparse class 2 uploads no shapes. It does not duplicate the indexing expression. It asserts the defective observations and exits 0 when reproduced.

## Impact and future acceptance

The helper can report success after creating wrong-class annotations or silently dropping a declared class. Validate IDs before remote writes and verify every parsed ID maps through the original class-ID dictionary. Explicitly reject unsupported sparse/negative IDs instead of misinterpreting them. Cover `-1`, a large negative ID, sparse names, and an undeclared positive ID.
