"""Drive the operator's main flow with real inputs and fake remote services."""

import importlib.util
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace as NS
from unittest.mock import MagicMock, patch

from PIL import Image

repo = next(
    parent
    for parent in Path(__file__).resolve().parents
    if (parent / "pyproject.toml").exists()
)
spec = importlib.util.spec_from_file_location(
    "upload_review", repo / "scripts/upload_dataset_to_cvat.py"
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def run_case(class_map, label_line):
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "images/train").mkdir(parents=True)
        (root / "labels/train").mkdir(parents=True)
        Image.new("RGB", (10, 10)).save(root / "images/train/a.jpg")
        (root / "labels/train/a.txt").write_text(label_line + "\n")
        yaml_path = root / "dataset.yaml"
        yaml_path.write_text(
            "path: .\ntrain: images/train\nnames: " + str(class_map) + "\n"
        )
        task = MagicMock(id=99, name="test-task", size=1)
        task.get_labels.return_value = [
            NS(id=10 + 10 * i, name=name) for i, name in enumerate(class_map.values())
        ]
        client = MagicMock()
        client.projects.create.return_value = NS(id=7, name="test-project")
        client.tasks.create_from_data.return_value = task
        manager = MagicMock()
        manager.__enter__.return_value = client
        config = NS(
            require_credentials=lambda: NS(
                host="http://cvat.invalid",
                username="test",
                password="test",
                organization=None,
            )
        )
        with (
            patch.object(module.CvatConfig, "load", return_value=config),
            patch.object(module, "make_client", return_value=manager),
            patch(
                "sys.argv",
                ["upload_dataset_to_cvat.py", "--yaml", str(yaml_path), "--tasks", "1"],
            ),
        ):
            module.main()
        shapes = (
            task.update_annotations.call_args.args[0].shapes
            if task.update_annotations.called
            else []
        )
        return [shape.label_id for shape in shapes]


negative = run_case({0: "first", 1: "last"}, "-1 0.5 0.5 0.1 0.1")
sparse = run_case({0: "first", 2: "third"}, "2 0.5 0.5 0.1 0.1")
print("Actual main() label IDs for invalid class -1:", negative)
print("Actual main() label IDs for declared sparse class 2:", sparse)
assert negative == [20]
assert sparse == []
