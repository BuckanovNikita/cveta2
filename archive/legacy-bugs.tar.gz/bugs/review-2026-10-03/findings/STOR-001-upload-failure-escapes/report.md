# STOR-001-upload-failure-escapes: S3 upload errors escape the transfer failure accounting

- Severity: Medium
- Status: Reproduced with the installed boto3 client and botocore Stubber
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`
- Historical relationship: new finding; no production changes made.

## Expected behavior and contract

S3Uploader.upload documents uploaded/skipped/failed counters, and run_s3_transfers promises one failed object is logged and counted while the rest continue. The CLI/API receive an unexpected exception rather than that contract.

## Observed behavior and cause

A 403 AccessDenied from an actual boto3 upload_file call is wrapped as boto3.exceptions.S3UploadFailedError. The configured retry predicate and transfer catch tuple do not include this type; the upload aborts instead of returning failed=1 and continuing the batch.

Source evidence: `cveta2/image_uploader.py:185-188,249-257; cveta2/s3_utils.py:40-48,77-95,140-144` (line numbers at the reviewed commit).

## Impact

Permission failures and transient faults exhausted by boto3 can abort uploads with a traceback. Other pending images may not be processed. This does not prove a retry-safe solution for ambiguous writes.

## Reproduction

Run from the repository root, using the locked development environment:

```bash
uv run --locked python bugs/review-2026-10-03/findings/STOR-001-upload-failure-escapes/reproduce.py
```

The script asserts the current defective observation and exits 0 when reproduced. It uses temporary files or an in-memory S3 boundary; it makes no network calls. See [observed output](observed-output.txt).

## Future acceptance assertion

Deny one object through boto3 upload_file; assert it is counted as failed and another permitted object is processed without an unexpected exception.
