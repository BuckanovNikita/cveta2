import boto3
from botocore.stub import Stubber
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from cveta2.image_downloader import CloudStorageInfo
from cveta2.image_uploader import S3Uploader

s3 = boto3.client(
    "s3",
    region_name="us-east-1",
    aws_access_key_id="test",
    aws_secret_access_key="test",
)
with TemporaryDirectory() as tmp:
    image = Path(tmp) / "a.jpg"
    image.write_bytes(b"image")
    with Stubber(s3) as stub:
        stub.add_client_error(
            "put_object",
            service_error_code="AccessDenied",
            service_message="denied",
            http_status_code=403,
        )
        with patch("cveta2.image_uploader.make_s3_client", return_value=s3):
            try:
                result = S3Uploader().upload(
                    CloudStorageInfo(
                        id=1, bucket="test-bucket", prefix="", endpoint_url=""
                    ),
                    {"a.jpg": image},
                    {"a.jpg": "a.jpg"},
                    set(),
                )
            except Exception as error:
                print("Observed exception:", type(error).__name__)
                assert type(error).__name__ == "S3UploadFailedError"
            else:
                raise AssertionError(f"Bug no longer observed: {result}")
