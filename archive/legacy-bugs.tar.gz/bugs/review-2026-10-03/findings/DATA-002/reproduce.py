"""Reproduce acceptance of a split outside the documented enum."""

import os
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory(prefix="cveta2-data-002-") as temporary:
    root = Path(temporary)
    os.environ["HOME"] = str(root / "home")
    os.environ["XDG_CACHE_HOME"] = str(root / "cache")
    os.environ["XDG_CONFIG_HOME"] = str(root / "config")

    import pandas as pd
    import yaml
    from loguru import logger
    from PIL import Image

    from cveta2.models import CSV_COLUMNS
    from cveta2.services.convert import convert_to_yolo

    logger.remove()

    source = root / "source"
    source.mkdir()
    Image.new("RGB", (8, 8), color="red").save(source / "a.jpg")

    row = dict.fromkeys(CSV_COLUMNS, None)
    row.update(
        image_name="a.jpg",
        image_width=8,
        image_height=8,
        instance_shape="box",
        instance_label="cat",
        bbox_x_tl=1,
        bbox_y_tl=1,
        bbox_x_br=4,
        bbox_y_br=4,
        split="validation",
    )
    csv_path = root / "dataset.csv"
    pd.DataFrame([row], columns=CSV_COLUMNS).to_csv(csv_path, index=False)

    output = root / "yolo"
    convert_to_yolo(csv_path, output, image_dirs=[source], link_mode="copy")
    config = yaml.safe_load((output / "dataset.yaml").read_text(encoding="utf-8"))
    files = sorted(
        str(path.relative_to(output)) for path in output.rglob("*") if path.is_file()
    )
    print("input split:", "validation")
    print("dataset.yaml split keys:", sorted(set(config) & {"train", "val", "test"}))
    print("written files:", files)
    assert not set(config) & {"train", "val", "test"}
    assert "images/validation/a.jpg" in files
