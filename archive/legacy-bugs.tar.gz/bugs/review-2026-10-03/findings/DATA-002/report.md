# DATA-002: export accepts unsupported split values and writes an unreferenced YOLO tree

- Severity: Medium
- Status: Reproduced
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`
- Historical relationship: new finding; no production changes made.

## Expected behavior and contract

`Split` and the dataset contract allow only `train`, `val`, `test`, or a missing value. Export requires a populated split, so an unsupported value should be rejected with `Cveta2Error` before output is written.

## Observed behavior and cause

`_validate_splits()` checks only null and empty cells. With `split=validation`, YOLO export writes `images/validation/a.jpg` and `labels/validation/a.txt`, but `_write_dataset_yaml()` emits keys only for `train`, `val`, and `test`. The command reports success while `dataset.yaml` references none of the exported data. COCO export shares the same incomplete validation and creates an undocumented split directory.

Source evidence: `cveta2/services/convert/common.py:222-230,259-261,277-281`; `cveta2/services/convert/yolo.py:159-164,186-188` (line numbers at the reviewed commit).

## Impact

A typo or hand-edited split can produce a successful-looking export that training tools see as empty. The files exist on disk, which makes the omission easy to miss.

## Reproduction

Run from the repository root:

```bash
uv run --locked python bugs/review-2026-10-03/findings/DATA-002/reproduce.py
```

The script uses an isolated temporary home and asserts the current defective output. See [observed output](observed-output.txt).

## Future acceptance assertion

Export a CSV with `split=validation`; assert conversion raises `Cveta2Error` naming the image, the invalid value, and the allowed split values, and creates no partial export.
