# UI-004 — `setup-clearml` can discard the chosen enabled state

- Severity: Low
- Status: Reproduced
- Commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`

## Expected contract

The setup command is documented as enabling or disabling ClearML integration
(`docs/cli.md:60-62`). A direct answer to its first prompt must be saved even
when the user skips every per-project mapping prompt.

## Actual observation

`run_setup_clearml()` applies the answer to an in-memory model
(`cveta2/commands/setup_clearml.py:43-45`) and only afterwards initializes
`changed = False` (`cveta2/commands/setup_clearml.py:53`). If no mapping changes,
the save block is skipped and the command logs `Ничего не изменено.`
(`cveta2/commands/setup_clearml.py:63-67`). The reproduction starts from
`enabled: true`, selects `false`, skips the sole unmapped project, and reloads
`true` from disk.

Command:

```text
uv run --locked python bugs/review-2026-10-03/findings/UI-004-setup-clearml-toggle-not-saved/reproduce.py
```

Observed output (log timestamp and temporary-directory suffix vary):

```text
Ничего не изменено.
before=True
selected=False
after=True
choice_persisted=False
```

## Impact

The wizard can explicitly accept an enable/disable answer, report that nothing
changed, and leave the prior behavior active. This is most visible for an
enabled configuration with no mappings.

## Future acceptance assertion

When `prompt_clearml_enabled()` returns a boolean different from the loaded
value, `run_setup_clearml()` persists it even if every project mapping is
skipped; a reload returns the selected boolean.

## Captured proof

The parent reran the reproduction independently. See [observed output](observed-output.txt) and the shared [reproduction results](../../evidence/reproduction-results.json). Exit 0 indicates the defective observation was reproduced, not that the intended behavior passed.
