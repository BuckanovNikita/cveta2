"""Reproduce setup-clearml dropping an enabled-state change."""

# ruff: noqa: I001, INP001, T201

import argparse
import os
import tempfile
from pathlib import Path
from unittest.mock import patch


with tempfile.TemporaryDirectory(prefix="cveta2-ui-004-") as raw_tmp:
    tmp = Path(raw_tmp)
    os.environ["HOME"] = str(tmp / "home")
    os.environ["XDG_CACHE_HOME"] = str(tmp / "xdg-cache")
    config = tmp / "profile" / "config.yaml"

    from cveta2.commands.setup_clearml import run_setup_clearml
    from cveta2.config import ClearmlConfig
    from cveta2.models import ProjectInfo
    from cveta2.projects_cache import OrgProjects, save_orgs_cache

    ClearmlConfig(enabled=True).save(config)
    save_orgs_cache(
        [
            OrgProjects(
                slug="",
                name="personal",
                projects=[ProjectInfo(id=1, name="project")],
            )
        ],
        config.parent / "projects.yaml",
    )
    before = ClearmlConfig.load(config).enabled
    with (
        patch(
            "cveta2.commands.setup_clearml.wizard.prompt_clearml_enabled",
            return_value=False,
        ),
        patch(
            "cveta2.commands.setup_clearml._prompt_project_mapping",
            return_value=None,
        ),
    ):
        run_setup_clearml(
            argparse.Namespace(config=str(config), list_only=False, reset=False)
        )
    after = ClearmlConfig.load(config).enabled
    print(f"before={before}")
    print("selected=False")
    print(f"after={after}")
    print(f"choice_persisted={after is False}")
    assert before is True and after is True
