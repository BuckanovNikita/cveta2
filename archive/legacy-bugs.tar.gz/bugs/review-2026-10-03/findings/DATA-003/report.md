# DATA-003: repeat export silently keeps stale image bytes

- Severity: Medium
- Status: Reproduced
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`
- Historical relationship: new finding; no production changes made.

## Expected behavior and contract

A conversion run should make the output dataset correspond to the current CSV and resolved source images. The YOLO guide explicitly supports repeat export to the same directory and describes that tree as conversion output.

## Observed behavior and cause

The shared `_link_or_copy()` helper returns whenever the destination path exists, without checking its content or link target. After the source image is replaced and conversion runs again, labels and metadata are rewritten but the old destination bytes remain. Both YOLO and COCO use this helper.

Source evidence: `cveta2/services/convert/common.py:130-147`; YOLO call sites `cveta2/services/convert/yolo.py:43-52,94-101`; COCO call site `cveta2/services/convert/coco.py:45-52` (line numbers at the reviewed commit).

## Impact

Current annotations can be paired with an earlier version of the image. Training and evaluation then use a dataset that does not match the source selected for the run, with no warning.

## Reproduction

Run from the repository root:

```bash
uv run --locked python bugs/review-2026-10-03/findings/DATA-003/reproduce.py
```

The script uses copy mode, replaces the source image between two exports, and asserts that the destination hash stays stale. See [observed output](observed-output.txt).

## Future acceptance assertion

Export in copy mode, replace a selected source image under the same name, and export again to the same directory; assert destination bytes match the current source. Add equivalent assertions for link modes according to their documented semantics.
