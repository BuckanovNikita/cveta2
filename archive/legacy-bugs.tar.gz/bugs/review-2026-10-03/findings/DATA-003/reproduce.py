"""Reproduce a stale copied image after export to the same destination."""

import hashlib
import os
import tempfile
from pathlib import Path


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()[:12]


with tempfile.TemporaryDirectory(prefix="cveta2-data-003-") as temporary:
    root = Path(temporary)
    os.environ["HOME"] = str(root / "home")
    os.environ["XDG_CACHE_HOME"] = str(root / "cache")
    os.environ["XDG_CONFIG_HOME"] = str(root / "config")

    import pandas as pd
    from loguru import logger
    from PIL import Image

    from cveta2.models import CSV_COLUMNS
    from cveta2.services.convert import convert_to_yolo

    logger.remove()

    source = root / "source"
    source.mkdir()
    source_image = source / "a.png"
    Image.new("RGB", (8, 8), color="red").save(source_image)

    row = dict.fromkeys(CSV_COLUMNS, None)
    row.update(
        image_name="a.png",
        image_width=8,
        image_height=8,
        instance_shape="none",
        split="train",
    )
    csv_path = root / "dataset.csv"
    pd.DataFrame([row], columns=CSV_COLUMNS).to_csv(csv_path, index=False)
    output = root / "yolo"

    convert_to_yolo(csv_path, output, image_dirs=[source], link_mode="copy")
    destination = output / "images" / "train" / "a.png"
    first_destination = digest(destination)

    Image.new("RGB", (8, 8), color="blue").save(source_image)
    current_source = digest(source_image)
    convert_to_yolo(csv_path, output, image_dirs=[source], link_mode="copy")
    second_destination = digest(destination)

    print("first destination hash:", first_destination)
    print("current source hash:", current_source)
    print("second destination hash:", second_destination)
    print("destination refreshed:", second_destination == current_source)
    assert second_destination == first_destination
    assert second_destination != current_source
