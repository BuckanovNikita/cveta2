# DATA-005: malformed dataset CSV escapes the service error boundary

- Severity: Low
- Status: Reproduced
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`
- Historical relationship: new finding; analogous to historical BR-08, but at the shared dataset CSV boundary.

## Expected behavior and contract

Service orchestration raises `Cveta2Error`, and the CLI converts that domain error to a concise message. `read_dataset_csv()` documents validation errors in that form.

## Observed behavior and cause

`read_dataset_csv()` translates `EmptyDataError` only. A malformed quoted CSV raises pandas `ParserError`, which propagates through merge, conversion, upload, and whats-new callers. The CLI catches only `Cveta2Error`, so command use ends in a Python traceback.

Source evidence: `cveta2/services/output.py:91-108`; CLI boundary `cveta2/cli.py:688-699` (line numbers at the reviewed commit).

## Impact

Malformed or truncated user input produces an internal traceback instead of an actionable file-specific error. Every workflow using the shared reader is affected.

## Reproduction

Run from the repository root:

```bash
uv run --locked python bugs/review-2026-10-03/findings/DATA-005/reproduce.py
```

The script uses an isolated temporary home and asserts that the raw pandas exception escapes. See [observed output](observed-output.txt).

## Future acceptance assertion

Read an unterminated quoted CSV through each public workflow that uses `read_dataset_csv()`; assert a `Cveta2Error` names the path and summarizes the parse failure, and CLI output contains no traceback.
