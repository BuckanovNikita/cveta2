"""Reproduce a raw pandas parser exception at the dataset I/O boundary."""

import os
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory(prefix="cveta2-data-005-") as temporary:
    root = Path(temporary)
    os.environ["HOME"] = str(root / "home")
    os.environ["XDG_CACHE_HOME"] = str(root / "cache")
    os.environ["XDG_CONFIG_HOME"] = str(root / "config")

    from loguru import logger

    from cveta2.exceptions import Cveta2Error
    from cveta2.services.output import read_dataset_csv

    logger.remove()

    csv_path = root / "broken.csv"
    csv_path.write_text('image_name,split\n"unterminated,train\n', encoding="utf-8")
    try:
        read_dataset_csv(csv_path, {"image_name", "split"})
    except Exception as error:
        print("exception type:", type(error).__name__)
        print("is Cveta2Error:", isinstance(error, Cveta2Error))
        print("message:", str(error).splitlines()[0])
        assert type(error).__name__ == "ParserError"
        assert not isinstance(error, Cveta2Error)
    else:
        raise AssertionError("malformed CSV unexpectedly succeeded")
