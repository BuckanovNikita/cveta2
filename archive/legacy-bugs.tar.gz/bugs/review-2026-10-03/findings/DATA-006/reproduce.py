"""Reproduce a raw YAML parser exception at the conversion boundary."""

import os
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory(prefix="cveta2-data-006-") as temporary:
    root = Path(temporary)
    os.environ["HOME"] = str(root / "home")
    os.environ["XDG_CACHE_HOME"] = str(root / "cache")
    os.environ["XDG_CONFIG_HOME"] = str(root / "config")

    from loguru import logger

    from cveta2.exceptions import Cveta2Error
    from cveta2.services.convert import convert_from_yolo

    logger.remove()

    input_dir = root / "input"
    input_dir.mkdir()
    (input_dir / "dataset.yaml").write_text(
        "names: [unterminated\ntrain: images/train\n", encoding="utf-8"
    )
    try:
        convert_from_yolo(input_dir, root / "output.csv")
    except Exception as error:
        print("exception type:", type(error).__name__)
        print("is Cveta2Error:", isinstance(error, Cveta2Error))
        print("message:", str(error).splitlines()[0])
        assert type(error).__name__ == "ParserError"
        assert not isinstance(error, Cveta2Error)
    else:
        raise AssertionError("malformed YAML unexpectedly succeeded")
