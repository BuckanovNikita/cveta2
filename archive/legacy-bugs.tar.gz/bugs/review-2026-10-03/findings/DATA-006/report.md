# DATA-006: malformed YOLO YAML escapes the conversion error boundary

- Severity: Low
- Status: Reproduced
- Reviewed commit: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`
- Historical relationship: new finding; analogous to historical BR-08, but in YOLO dataset and class-name inputs.

## Expected behavior and contract

Conversion services raise `Cveta2Error`, allowing the CLI to present a concise user-facing failure. Invalid `dataset.yaml` or `--names-file` content should identify the offending path without a traceback.

## Observed behavior and cause

Both YOLO YAML reads call `yaml.safe_load()` directly. Syntax errors raise PyYAML `ParserError`, which is not translated at the service boundary and is not caught by the CLI.

Source evidence: `cveta2/services/convert/yolo.py:275-284,393-406`; CLI boundary `cveta2/cli.py:688-699` (line numbers at the reviewed commit).

## Impact

A malformed or partially written YOLO config aborts conversion with an implementation traceback rather than a stable domain error. The same failure mode exists for a malformed names file in prediction mode.

## Reproduction

Run from the repository root:

```bash
uv run --locked python bugs/review-2026-10-03/findings/DATA-006/reproduce.py
```

The script uses an isolated temporary home and asserts that the raw PyYAML exception escapes. See [observed output](observed-output.txt).

## Future acceptance assertion

Convert with malformed `dataset.yaml` and malformed `--names-file` inputs; assert both raise `Cveta2Error` naming the source path and CLI output contains no traceback.
