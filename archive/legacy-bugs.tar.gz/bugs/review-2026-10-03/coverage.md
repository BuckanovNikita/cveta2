# Review inventory

Reviewed revision: `875dca9b5cfc5bb48218257624defe3c18bc4f6e`. All 76 tracked application Python modules were assigned and reviewed. The file inventory below records ownership and links to subsystem evidence, including areas where no additional finding met the evidence threshold.

| Module | Owner | Review status |
|---|---|---|
| `cveta2/__init__.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/__main__.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/_clearml/__init__.py` | Parent | Reviewed; [evidence](evidence/parent-review.md) |
| `cveta2/_clearml/_dataset.py` | Parent | Reviewed; [evidence](evidence/parent-review.md) |
| `cveta2/_client/__init__.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client/assembly.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client/connection.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client/context.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client/dtos.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client/extractors.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client/mapping.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client/ports.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client/sdk_adapter.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client/sdk_convert.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client/sdk_requests.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client_ops/__init__.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client_ops/base.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client_ops/fetch.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client_ops/images.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client_ops/read.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client_ops/session.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client_ops/shared.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client_ops/task_ops.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_client_ops/write.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/_concurrency.py` | Parent | Reviewed; [evidence](evidence/parent-review.md) |
| `cveta2/_retry.py` | Parent | Reviewed; [evidence](evidence/parent-review.md) |
| `cveta2/api.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/cli.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/client.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/commands/__init__.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/_bootstrap.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/_helpers.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/convert.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/doctor.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/fetch.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/ignore.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/interactive/__init__.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/interactive/_history.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/interactive/_questionary.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/interactive/credentials.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/interactive/entities.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/interactive/primitives.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/interactive/wizard.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/labels.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/merge.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/s3_sync.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/setup.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/setup_clearml.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/task_ops.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/upload.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/commands/whats_new.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/config.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/dataset_partition.py` | Dataset | Reviewed; [evidence](evidence/dataset-review.md) |
| `cveta2/exceptions.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/fs_utils.py` | Parent | Reviewed; [evidence](evidence/parent-review.md) |
| `cveta2/image_downloader.py` | Parent | Reviewed; [evidence](evidence/parent-review.md) |
| `cveta2/image_uploader.py` | Parent | Reviewed; [evidence](evidence/parent-review.md) |
| `cveta2/models.py` | Dataset | Reviewed; [evidence](evidence/dataset-review.md) |
| `cveta2/presets/__init__.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/projects_cache.py` | Interface | Reviewed; [evidence](evidence/interface-review.md) |
| `cveta2/s3_types.py` | Parent | Reviewed; [evidence](evidence/parent-review.md) |
| `cveta2/s3_utils.py` | Parent | Reviewed; [evidence](evidence/parent-review.md) |
| `cveta2/services/__init__.py` | Parent | Reviewed; [evidence](evidence/parent-review.md) |
| `cveta2/services/convert/__init__.py` | Dataset | Reviewed; [evidence](evidence/dataset-review.md) |
| `cveta2/services/convert/coco.py` | Dataset | Reviewed; [evidence](evidence/dataset-review.md) |
| `cveta2/services/convert/common.py` | Dataset | Reviewed; [evidence](evidence/dataset-review.md) |
| `cveta2/services/convert/yolo.py` | Dataset | Reviewed; [evidence](evidence/dataset-review.md) |
| `cveta2/services/fetch.py` | Dataset | Reviewed; [evidence](evidence/dataset-review.md) |
| `cveta2/services/merge.py` | Dataset | Reviewed; [evidence](evidence/dataset-review.md) |
| `cveta2/services/output.py` | Dataset | Reviewed; [evidence](evidence/dataset-review.md) |
| `cveta2/services/resolve.py` | Parent | Reviewed; [evidence](evidence/parent-review.md) |
| `cveta2/services/task_ops.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/services/upload.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |
| `cveta2/services/whats_new.py` | Dataset | Reviewed; [evidence](evidence/dataset-review.md) |
| `cveta2/task_cache.py` | Parent | Reviewed; [evidence](evidence/parent-review.md) |
| `cveta2/upload_manifest.py` | CVAT | Reviewed; [evidence](evidence/cvat-review.md) |

## Additional repository coverage

- Maintained operator and quality/lifecycle scripts: parent inventory and actual check logs.
- Tests: full isolated suite on 3.11/3.12, serial opt-in worker/cache cases, full configured mutation scope, live integration and live-fixture suites. Static test/contract inspection was organized by subsystem; no claim that every test assertion was independently audited line by line.
- User docs, dataset/architecture contracts, README/CONTRIBUTING, specs/history, manifest/hook configuration and package build: inspected against public behavior and validated through documentation checks.
- Project-installed Spec Kit and agent metadata: workflow/selection/template integration inspected, shell syntax checked; upstream internals were not exhaustively behavior-tested.
- Unavailable coverage: Python 3.10/3.13, non-Linux platforms, external dependency/server internals, exhaustive fault injection/property testing. See [limitations](limitations.md).

Coverage output: [branch-aware file data](evidence/coverage.json). It is execution evidence, not a correctness certificate.
